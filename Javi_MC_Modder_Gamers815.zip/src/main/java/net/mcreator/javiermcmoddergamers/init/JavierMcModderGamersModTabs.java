/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.javiermcmoddergamers.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.network.chat.Component;
import net.minecraft.core.registries.Registries;

import net.mcreator.javiermcmoddergamers.JavierMcModderGamersMod;

@EventBusSubscriber(bus = EventBusSubscriber.Bus.MOD)
public class JavierMcModderGamersModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, JavierMcModderGamersMod.MODID);
	public static final DeferredHolder<CreativeModeTab, CreativeModeTab> JAVITAB = REGISTRY.register("javitab",
			() -> CreativeModeTab.builder().title(Component.translatable("item_group.javier_mc_modder_gamers.javitab")).icon(() -> new ItemStack(JavierMcModderGamersModItems.BORINGOREING.get())).displayItems((parameters, tabData) -> {
				tabData.accept(JavierMcModderGamersModBlocks.FACES.get().asItem());
				tabData.accept(JavierMcModderGamersModItems.BORINGOREING.get());
				tabData.accept(JavierMcModderGamersModBlocks.BORINGBLOCK.get().asItem());
				tabData.accept(JavierMcModderGamersModItems.NOTBORINGSWORD.get());
				tabData.accept(JavierMcModderGamersModItems.HEHHEHAXE.get());
				tabData.accept(JavierMcModderGamersModItems.BATTLEAMOUR_HELMET.get());
				tabData.accept(JavierMcModderGamersModItems.BATTLEAMOUR_CHESTPLATE.get());
				tabData.accept(JavierMcModderGamersModItems.BATTLEAMOUR_LEGGINGS.get());
				tabData.accept(JavierMcModderGamersModItems.BATTLEAMOUR_BOOTS.get());
				tabData.accept(JavierMcModderGamersModItems.SICKAXE.get());
				tabData.accept(JavierMcModderGamersModBlocks.LIGHTTNT.get().asItem());
				tabData.accept(JavierMcModderGamersModBlocks.PURPLEGRASS.get().asItem());
				tabData.accept(JavierMcModderGamersModBlocks.LIMEWOOD.get().asItem());
				tabData.accept(JavierMcModderGamersModBlocks.LBLUEUNDERWATER.get().asItem());
				tabData.accept(JavierMcModderGamersModBlocks.PINKLEAVES.get().asItem());
				tabData.accept(JavierMcModderGamersModBlocks.LPLANK.get().asItem());
				tabData.accept(JavierMcModderGamersModItems.LIMEWOODSWORD.get());
				tabData.accept(JavierMcModderGamersModItems.HAPPYSLIME_SPAWN_EGG.get());
			}).build());

	@SubscribeEvent
	public static void buildTabContentsVanilla(BuildCreativeModeTabContentsEvent tabData) {
		if (tabData.getTabKey() == CreativeModeTabs.COMBAT) {
			tabData.accept(JavierMcModderGamersModItems.FIRE.get());
			tabData.accept(JavierMcModderGamersModItems.FIREGUN.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) {
			tabData.accept(JavierMcModderGamersModItems.HAPPY_DIMENSION.get());
		}
	}
}