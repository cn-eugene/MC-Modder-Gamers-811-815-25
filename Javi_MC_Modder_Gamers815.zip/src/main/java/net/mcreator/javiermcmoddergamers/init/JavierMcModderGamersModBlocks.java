/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.javiermcmoddergamers.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredBlock;

import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.Block;

import net.mcreator.javiermcmoddergamers.block.PurplegrassBlock;
import net.mcreator.javiermcmoddergamers.block.PinkleavesBlock;
import net.mcreator.javiermcmoddergamers.block.LplankBlock;
import net.mcreator.javiermcmoddergamers.block.LimewoodBlock;
import net.mcreator.javiermcmoddergamers.block.LighttntBlock;
import net.mcreator.javiermcmoddergamers.block.LblueunderwaterBlock;
import net.mcreator.javiermcmoddergamers.block.HappyDimensionPortalBlock;
import net.mcreator.javiermcmoddergamers.block.FacesBlock;
import net.mcreator.javiermcmoddergamers.block.BoringblockBlock;
import net.mcreator.javiermcmoddergamers.JavierMcModderGamersMod;

import java.util.function.Function;

public class JavierMcModderGamersModBlocks {
	public static final DeferredRegister.Blocks REGISTRY = DeferredRegister.createBlocks(JavierMcModderGamersMod.MODID);
	public static final DeferredBlock<Block> FACES = register("faces", FacesBlock::new);
	public static final DeferredBlock<Block> BORINGBLOCK = register("boringblock", BoringblockBlock::new);
	public static final DeferredBlock<Block> LIGHTTNT = register("lighttnt", LighttntBlock::new);
	public static final DeferredBlock<Block> PURPLEGRASS = register("purplegrass", PurplegrassBlock::new);
	public static final DeferredBlock<Block> LIMEWOOD = register("limewood", LimewoodBlock::new);
	public static final DeferredBlock<Block> LBLUEUNDERWATER = register("lblueunderwater", LblueunderwaterBlock::new);
	public static final DeferredBlock<Block> PINKLEAVES = register("pinkleaves", PinkleavesBlock::new);
	public static final DeferredBlock<Block> LPLANK = register("lplank", LplankBlock::new);
	public static final DeferredBlock<Block> HAPPY_DIMENSION_PORTAL = register("happy_dimension_portal", HappyDimensionPortalBlock::new);

	// Start of user code block custom blocks
	// End of user code block custom blocks
	private static <B extends Block> DeferredBlock<B> register(String name, Function<BlockBehaviour.Properties, ? extends B> supplier) {
		return REGISTRY.registerBlock(name, supplier, BlockBehaviour.Properties.of());
	}
}