/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.javiermcmoddergamers.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.SpawnEggItem;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.mcreator.javiermcmoddergamers.item.SickaxeItem;
import net.mcreator.javiermcmoddergamers.item.NotboringswordItem;
import net.mcreator.javiermcmoddergamers.item.LimewoodswordItem;
import net.mcreator.javiermcmoddergamers.item.HehhehaxeItem;
import net.mcreator.javiermcmoddergamers.item.HappyDimensionItem;
import net.mcreator.javiermcmoddergamers.item.FiregunItem;
import net.mcreator.javiermcmoddergamers.item.FireItem;
import net.mcreator.javiermcmoddergamers.item.BoringoreingItem;
import net.mcreator.javiermcmoddergamers.item.BattleamourItem;
import net.mcreator.javiermcmoddergamers.JavierMcModderGamersMod;

import java.util.function.Function;

public class JavierMcModderGamersModItems {
	public static final DeferredRegister.Items REGISTRY = DeferredRegister.createItems(JavierMcModderGamersMod.MODID);
	public static final DeferredItem<Item> FACES = block(JavierMcModderGamersModBlocks.FACES, new Item.Properties().rarity(Rarity.RARE).fireResistant());
	public static final DeferredItem<Item> BORINGOREING = register("boringoreing", BoringoreingItem::new);
	public static final DeferredItem<Item> BORINGBLOCK = block(JavierMcModderGamersModBlocks.BORINGBLOCK, new Item.Properties().stacksTo(80).rarity(Rarity.RARE));
	public static final DeferredItem<Item> NOTBORINGSWORD = register("notboringsword", NotboringswordItem::new);
	public static final DeferredItem<Item> HEHHEHAXE = register("hehhehaxe", HehhehaxeItem::new);
	public static final DeferredItem<Item> BATTLEAMOUR_HELMET = register("battleamour_helmet", BattleamourItem.Helmet::new);
	public static final DeferredItem<Item> BATTLEAMOUR_CHESTPLATE = register("battleamour_chestplate", BattleamourItem.Chestplate::new);
	public static final DeferredItem<Item> BATTLEAMOUR_LEGGINGS = register("battleamour_leggings", BattleamourItem.Leggings::new);
	public static final DeferredItem<Item> BATTLEAMOUR_BOOTS = register("battleamour_boots", BattleamourItem.Boots::new);
	public static final DeferredItem<Item> SICKAXE = register("sickaxe", SickaxeItem::new);
	public static final DeferredItem<Item> FIRE = register("fire", FireItem::new);
	public static final DeferredItem<Item> FIREGUN = register("firegun", FiregunItem::new);
	public static final DeferredItem<Item> LIGHTTNT = block(JavierMcModderGamersModBlocks.LIGHTTNT, new Item.Properties().stacksTo(99).rarity(Rarity.RARE));
	public static final DeferredItem<Item> PURPLEGRASS = block(JavierMcModderGamersModBlocks.PURPLEGRASS);
	public static final DeferredItem<Item> LIMEWOOD = block(JavierMcModderGamersModBlocks.LIMEWOOD);
	public static final DeferredItem<Item> LBLUEUNDERWATER = block(JavierMcModderGamersModBlocks.LBLUEUNDERWATER);
	public static final DeferredItem<Item> PINKLEAVES = block(JavierMcModderGamersModBlocks.PINKLEAVES);
	public static final DeferredItem<Item> LPLANK = block(JavierMcModderGamersModBlocks.LPLANK);
	public static final DeferredItem<Item> LIMEWOODSWORD = register("limewoodsword", LimewoodswordItem::new);
	public static final DeferredItem<Item> HAPPY_DIMENSION = register("happy_dimension", HappyDimensionItem::new);
	public static final DeferredItem<Item> HAPPYSLIME_SPAWN_EGG = register("happyslime_spawn_egg", properties -> new SpawnEggItem(JavierMcModderGamersModEntities.HAPPYSLIME.get(), properties));

	// Start of user code block custom items
	// End of user code block custom items
	private static <I extends Item> DeferredItem<I> register(String name, Function<Item.Properties, ? extends I> supplier) {
		return REGISTRY.registerItem(name, supplier, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block) {
		return block(block, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block, Item.Properties properties) {
		return REGISTRY.registerItem(block.getId().getPath(), prop -> new BlockItem(block.get(), prop), properties);
	}
}