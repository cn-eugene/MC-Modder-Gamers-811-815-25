package net.mcreator.marionmcmoddergamers.block;

import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.Block;

public class EnderbliBlock extends Block {
	public EnderbliBlock(BlockBehaviour.Properties properties) {
		super(properties.sound(SoundType.VINE).strength(1.05f, 10f).noCollission());
	}

	@Override
	public int getLightBlock(BlockState state) {
		return 15;
	}
}