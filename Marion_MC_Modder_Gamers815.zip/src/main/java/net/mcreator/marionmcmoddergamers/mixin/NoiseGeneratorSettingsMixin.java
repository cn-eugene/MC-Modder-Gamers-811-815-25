package net.mcreator.marionmcmoddergamers.mixin;

import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.Mixin;

import net.minecraft.world.level.levelgen.SurfaceRules;
import net.minecraft.world.level.levelgen.NoiseGeneratorSettings;
import net.minecraft.world.level.dimension.DimensionType;
import net.minecraft.core.Holder;

import net.mcreator.marionmcmoddergamers.init.MarionMcModderGamersModBiomes;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapmethod.WrapMethod;

@Mixin(NoiseGeneratorSettings.class)
public class NoiseGeneratorSettingsMixin implements MarionMcModderGamersModBiomes.MarionMcModderGamersModNoiseGeneratorSettings {
	@Unique
	private Holder<DimensionType> marion_mc_modder_gamers_dimensionTypeReference;

	@WrapMethod(method = "surfaceRule")
	public SurfaceRules.RuleSource surfaceRule(Operation<SurfaceRules.RuleSource> original) {
		SurfaceRules.RuleSource retval = original.call();
		if (this.marion_mc_modder_gamers_dimensionTypeReference != null) {
			retval = MarionMcModderGamersModBiomes.adaptSurfaceRule(retval, this.marion_mc_modder_gamers_dimensionTypeReference);
		}
		return retval;
	}

	@Override
	public void setmarion_mc_modder_gamersDimensionTypeReference(Holder<DimensionType> dimensionType) {
		this.marion_mc_modder_gamers_dimensionTypeReference = dimensionType;
	}
}