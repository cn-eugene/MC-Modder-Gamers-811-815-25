package net.mcreator.marionmcmoddergamers.item;

import net.minecraft.world.item.Item;

public class VoidstoneItem extends Item {
	public VoidstoneItem(Item.Properties properties) {
		super(properties);
	}
}