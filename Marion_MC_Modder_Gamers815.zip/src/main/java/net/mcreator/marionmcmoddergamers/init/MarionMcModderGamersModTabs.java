/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.marionmcmoddergamers.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.core.registries.Registries;

import net.mcreator.marionmcmoddergamers.MarionMcModderGamersMod;

@EventBusSubscriber(bus = EventBusSubscriber.Bus.MOD)
public class MarionMcModderGamersModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, MarionMcModderGamersMod.MODID);

	@SubscribeEvent
	public static void buildTabContentsVanilla(BuildCreativeModeTabContentsEvent tabData) {
		if (tabData.getTabKey() == CreativeModeTabs.NATURAL_BLOCKS) {
			tabData.accept(MarionMcModderGamersModBlocks.ENDERBLI.get().asItem());
			tabData.accept(MarionMcModderGamersModBlocks.VOIDORE.get().asItem());
		} else if (tabData.getTabKey() == CreativeModeTabs.COMBAT) {
			tabData.accept(MarionMcModderGamersModItems.VOIDSWORD.get());
			tabData.accept(MarionMcModderGamersModItems.VOIDARMOR_HELMET.get());
			tabData.accept(MarionMcModderGamersModItems.VOIDARMOR_CHESTPLATE.get());
			tabData.accept(MarionMcModderGamersModItems.VOIDARMOR_LEGGINGS.get());
			tabData.accept(MarionMcModderGamersModItems.VOIDARMOR_BOOTS.get());
			tabData.accept(MarionMcModderGamersModItems.AAAAAAAAAAAAAAAAAAAAAAROW.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) {
			tabData.accept(MarionMcModderGamersModItems.VOIDPICKAXE.get());
			tabData.accept(MarionMcModderGamersModItems.VOIDAXE.get());
			tabData.accept(MarionMcModderGamersModItems.VOIDSHOVEL.get());
			tabData.accept(MarionMcModderGamersModItems.VOIDHOE.get());
			tabData.accept(MarionMcModderGamersModItems.VOIDSHEARS.get());
			tabData.accept(MarionMcModderGamersModItems.FOXPLACE.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.SPAWN_EGGS) {
			tabData.accept(MarionMcModderGamersModItems.FOXPERSON_SPAWN_EGG.get());
		}
	}
}