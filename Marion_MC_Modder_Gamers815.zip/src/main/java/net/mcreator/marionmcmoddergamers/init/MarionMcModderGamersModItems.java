/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.marionmcmoddergamers.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.SpawnEggItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.mcreator.marionmcmoddergamers.item.VoidswordItem;
import net.mcreator.marionmcmoddergamers.item.VoidstoneItem;
import net.mcreator.marionmcmoddergamers.item.VoidshovelItem;
import net.mcreator.marionmcmoddergamers.item.VoidshearsItem;
import net.mcreator.marionmcmoddergamers.item.VoidpickaxeItem;
import net.mcreator.marionmcmoddergamers.item.VoidhoeItem;
import net.mcreator.marionmcmoddergamers.item.VoidaxeItem;
import net.mcreator.marionmcmoddergamers.item.VoidarmorItem;
import net.mcreator.marionmcmoddergamers.item.SeethroughbowItem;
import net.mcreator.marionmcmoddergamers.item.FoxplaceItem;
import net.mcreator.marionmcmoddergamers.item.AmethystItem;
import net.mcreator.marionmcmoddergamers.item.AaaaaaaaaaaaaaaaaaaaaarowItem;
import net.mcreator.marionmcmoddergamers.MarionMcModderGamersMod;

import java.util.function.Function;

public class MarionMcModderGamersModItems {
	public static final DeferredRegister.Items REGISTRY = DeferredRegister.createItems(MarionMcModderGamersMod.MODID);
	public static final DeferredItem<Item> ENDERBLI = block(MarionMcModderGamersModBlocks.ENDERBLI);
	public static final DeferredItem<Item> VOIDSTONE = register("voidstone", VoidstoneItem::new);
	public static final DeferredItem<Item> VOIDORE = block(MarionMcModderGamersModBlocks.VOIDORE);
	public static final DeferredItem<Item> AMETHYST = register("amethyst", AmethystItem::new);
	public static final DeferredItem<Item> VOIDSWORD = register("voidsword", VoidswordItem::new);
	public static final DeferredItem<Item> VOIDPICKAXE = register("voidpickaxe", VoidpickaxeItem::new);
	public static final DeferredItem<Item> VOIDAXE = register("voidaxe", VoidaxeItem::new);
	public static final DeferredItem<Item> VOIDSHOVEL = register("voidshovel", VoidshovelItem::new);
	public static final DeferredItem<Item> VOIDHOE = register("voidhoe", VoidhoeItem::new);
	public static final DeferredItem<Item> VOIDSHEARS = register("voidshears", VoidshearsItem::new);
	public static final DeferredItem<Item> VOIDARMOR_HELMET = register("voidarmor_helmet", VoidarmorItem.Helmet::new);
	public static final DeferredItem<Item> VOIDARMOR_CHESTPLATE = register("voidarmor_chestplate", VoidarmorItem.Chestplate::new);
	public static final DeferredItem<Item> VOIDARMOR_LEGGINGS = register("voidarmor_leggings", VoidarmorItem.Leggings::new);
	public static final DeferredItem<Item> VOIDARMOR_BOOTS = register("voidarmor_boots", VoidarmorItem.Boots::new);
	public static final DeferredItem<Item> SEETHROUGHBOW = register("seethroughbow", SeethroughbowItem::new);
	public static final DeferredItem<Item> AAAAAAAAAAAAAAAAAAAAAAROW = register("aaaaaaaaaaaaaaaaaaaaaarow", AaaaaaaaaaaaaaaaaaaaaarowItem::new);
	public static final DeferredItem<Item> FOXGRASS = block(MarionMcModderGamersModBlocks.FOXGRASS);
	public static final DeferredItem<Item> SUPERNOVA_TNT = block(MarionMcModderGamersModBlocks.SUPERNOVA_TNT);
	public static final DeferredItem<Item> FOXLOG = block(MarionMcModderGamersModBlocks.FOXLOG);
	public static final DeferredItem<Item> UNDERWATERFOXTHINGY = block(MarionMcModderGamersModBlocks.UNDERWATERFOXTHINGY);
	public static final DeferredItem<Item> GBU = block(MarionMcModderGamersModBlocks.GBU);
	public static final DeferredItem<Item> FOXPLACE = register("foxplace", FoxplaceItem::new);
	public static final DeferredItem<Item> FOXPERSON_SPAWN_EGG = register("foxperson_spawn_egg", properties -> new SpawnEggItem(MarionMcModderGamersModEntities.FOXPERSON.get(), properties));

	// Start of user code block custom items
	// End of user code block custom items
	private static <I extends Item> DeferredItem<I> register(String name, Function<Item.Properties, ? extends I> supplier) {
		return REGISTRY.registerItem(name, supplier, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block) {
		return block(block, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block, Item.Properties properties) {
		return REGISTRY.registerItem(block.getId().getPath(), prop -> new BlockItem(block.get(), prop), properties);
	}
}