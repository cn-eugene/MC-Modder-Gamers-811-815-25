/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.marionmcmoddergamers.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredBlock;

import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.Block;

import net.mcreator.marionmcmoddergamers.block.VoidoreBlock;
import net.mcreator.marionmcmoddergamers.block.UnderwaterfoxthingyBlock;
import net.mcreator.marionmcmoddergamers.block.SupernovaTNTBlock;
import net.mcreator.marionmcmoddergamers.block.GbuBlock;
import net.mcreator.marionmcmoddergamers.block.FoxplacePortalBlock;
import net.mcreator.marionmcmoddergamers.block.FoxlogBlock;
import net.mcreator.marionmcmoddergamers.block.FoxgrassBlock;
import net.mcreator.marionmcmoddergamers.block.EnderbliBlock;
import net.mcreator.marionmcmoddergamers.MarionMcModderGamersMod;

import java.util.function.Function;

public class MarionMcModderGamersModBlocks {
	public static final DeferredRegister.Blocks REGISTRY = DeferredRegister.createBlocks(MarionMcModderGamersMod.MODID);
	public static final DeferredBlock<Block> ENDERBLI = register("enderbli", EnderbliBlock::new);
	public static final DeferredBlock<Block> VOIDORE = register("voidore", VoidoreBlock::new);
	public static final DeferredBlock<Block> FOXGRASS = register("foxgrass", FoxgrassBlock::new);
	public static final DeferredBlock<Block> SUPERNOVA_TNT = register("supernova_tnt", SupernovaTNTBlock::new);
	public static final DeferredBlock<Block> FOXLOG = register("foxlog", FoxlogBlock::new);
	public static final DeferredBlock<Block> UNDERWATERFOXTHINGY = register("underwaterfoxthingy", UnderwaterfoxthingyBlock::new);
	public static final DeferredBlock<Block> GBU = register("gbu", GbuBlock::new);
	public static final DeferredBlock<Block> FOXPLACE_PORTAL = register("foxplace_portal", FoxplacePortalBlock::new);

	// Start of user code block custom blocks
	// End of user code block custom blocks
	private static <B extends Block> DeferredBlock<B> register(String name, Function<BlockBehaviour.Properties, ? extends B> supplier) {
		return REGISTRY.registerBlock(name, supplier, BlockBehaviour.Properties.of());
	}
}