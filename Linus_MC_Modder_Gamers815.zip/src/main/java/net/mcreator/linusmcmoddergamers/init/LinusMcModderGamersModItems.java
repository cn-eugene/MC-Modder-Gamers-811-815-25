/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.linusmcmoddergamers.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.SpawnEggItem;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.mcreator.linusmcmoddergamers.item.RainbowdimensionItem;
import net.mcreator.linusmcmoddergamers.item.PistolItem;
import net.mcreator.linusmcmoddergamers.item.BulletItem;
import net.mcreator.linusmcmoddergamers.item.AmethestswordItem;
import net.mcreator.linusmcmoddergamers.item.AmethestpickaxeItem;
import net.mcreator.linusmcmoddergamers.item.AmethestIngotItem;
import net.mcreator.linusmcmoddergamers.item.AmethestArmorItem;
import net.mcreator.linusmcmoddergamers.LinusMcModderGamersMod;

import java.util.function.Function;

public class LinusMcModderGamersModItems {
	public static final DeferredRegister.Items REGISTRY = DeferredRegister.createItems(LinusMcModderGamersMod.MODID);
	public static final DeferredItem<Item> RAINBOW_BLOCK = block(LinusMcModderGamersModBlocks.RAINBOW_BLOCK);
	public static final DeferredItem<Item> AMETHEST_INGOT = register("amethest_ingot", AmethestIngotItem::new);
	public static final DeferredItem<Item> AMETHESTSWORD = register("amethestsword", AmethestswordItem::new);
	public static final DeferredItem<Item> AMETHESTPICKAXE = register("amethestpickaxe", AmethestpickaxeItem::new);
	public static final DeferredItem<Item> AMETHEST_ARMOR_HELMET = register("amethest_armor_helmet", AmethestArmorItem.Helmet::new);
	public static final DeferredItem<Item> AMETHEST_ARMOR_CHESTPLATE = register("amethest_armor_chestplate", AmethestArmorItem.Chestplate::new);
	public static final DeferredItem<Item> AMETHEST_ARMOR_LEGGINGS = register("amethest_armor_leggings", AmethestArmorItem.Leggings::new);
	public static final DeferredItem<Item> AMETHEST_ARMOR_BOOTS = register("amethest_armor_boots", AmethestArmorItem.Boots::new);
	public static final DeferredItem<Item> AMETHESTORE = block(LinusMcModderGamersModBlocks.AMETHESTORE, new Item.Properties().rarity(Rarity.RARE));
	public static final DeferredItem<Item> SLIME_TNT = block(LinusMcModderGamersModBlocks.SLIME_TNT);
	public static final DeferredItem<Item> GRAYGRASSBLOCK = block(LinusMcModderGamersModBlocks.GRAYGRASSBLOCK);
	public static final DeferredItem<Item> GRAYLOG = block(LinusMcModderGamersModBlocks.GRAYLOG);
	public static final DeferredItem<Item> GRAY_LEAVES = block(LinusMcModderGamersModBlocks.GRAY_LEAVES);
	public static final DeferredItem<Item> GRAVEL = block(LinusMcModderGamersModBlocks.GRAVEL);
	public static final DeferredItem<Item> RAINBOWDIMENSION = register("rainbowdimension", RainbowdimensionItem::new);
	public static final DeferredItem<Item> COLORFULALLAY_SPAWN_EGG = register("colorfulallay_spawn_egg", properties -> new SpawnEggItem(LinusMcModderGamersModEntities.COLORFULALLAY.get(), properties));
	public static final DeferredItem<Item> PISTOL = register("pistol", PistolItem::new);
	public static final DeferredItem<Item> BULLET = register("bullet", BulletItem::new);

	// Start of user code block custom items
	// End of user code block custom items
	private static <I extends Item> DeferredItem<I> register(String name, Function<Item.Properties, ? extends I> supplier) {
		return REGISTRY.registerItem(name, supplier, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block) {
		return block(block, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block, Item.Properties properties) {
		return REGISTRY.registerItem(block.getId().getPath(), prop -> new BlockItem(block.get(), prop), properties);
	}
}