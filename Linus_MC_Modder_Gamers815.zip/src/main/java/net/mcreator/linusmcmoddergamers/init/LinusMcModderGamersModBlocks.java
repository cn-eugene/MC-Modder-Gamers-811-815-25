/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.linusmcmoddergamers.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredBlock;

import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.Block;

import net.mcreator.linusmcmoddergamers.block.SlimeTNTBlock;
import net.mcreator.linusmcmoddergamers.block.RainbowdimensionPortalBlock;
import net.mcreator.linusmcmoddergamers.block.RainbowBlockBlock;
import net.mcreator.linusmcmoddergamers.block.GraylogBlock;
import net.mcreator.linusmcmoddergamers.block.GraygrassblockBlock;
import net.mcreator.linusmcmoddergamers.block.GrayLeavesBlock;
import net.mcreator.linusmcmoddergamers.block.GravelBlock;
import net.mcreator.linusmcmoddergamers.block.AmethestoreBlock;
import net.mcreator.linusmcmoddergamers.LinusMcModderGamersMod;

import java.util.function.Function;

public class LinusMcModderGamersModBlocks {
	public static final DeferredRegister.Blocks REGISTRY = DeferredRegister.createBlocks(LinusMcModderGamersMod.MODID);
	public static final DeferredBlock<Block> RAINBOW_BLOCK = register("rainbow_block", RainbowBlockBlock::new);
	public static final DeferredBlock<Block> AMETHESTORE = register("amethestore", AmethestoreBlock::new);
	public static final DeferredBlock<Block> SLIME_TNT = register("slime_tnt", SlimeTNTBlock::new);
	public static final DeferredBlock<Block> GRAYGRASSBLOCK = register("graygrassblock", GraygrassblockBlock::new);
	public static final DeferredBlock<Block> GRAYLOG = register("graylog", GraylogBlock::new);
	public static final DeferredBlock<Block> GRAY_LEAVES = register("gray_leaves", GrayLeavesBlock::new);
	public static final DeferredBlock<Block> GRAVEL = register("gravel", GravelBlock::new);
	public static final DeferredBlock<Block> RAINBOWDIMENSION_PORTAL = register("rainbowdimension_portal", RainbowdimensionPortalBlock::new);

	// Start of user code block custom blocks
	// End of user code block custom blocks
	private static <B extends Block> DeferredBlock<B> register(String name, Function<BlockBehaviour.Properties, ? extends B> supplier) {
		return REGISTRY.registerBlock(name, supplier, BlockBehaviour.Properties.of());
	}
}