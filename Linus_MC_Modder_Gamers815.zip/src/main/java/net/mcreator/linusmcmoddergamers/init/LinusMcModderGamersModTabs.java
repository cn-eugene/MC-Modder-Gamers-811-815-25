/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.linusmcmoddergamers.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.network.chat.Component;
import net.minecraft.core.registries.Registries;

import net.mcreator.linusmcmoddergamers.LinusMcModderGamersMod;

@EventBusSubscriber(bus = EventBusSubscriber.Bus.MOD)
public class LinusMcModderGamersModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, LinusMcModderGamersMod.MODID);
	public static final DeferredHolder<CreativeModeTab, CreativeModeTab> MODDERTAB = REGISTRY.register("moddertab",
			() -> CreativeModeTab.builder().title(Component.translatable("item_group.linus_mc_modder_gamers.moddertab")).icon(() -> new ItemStack(LinusMcModderGamersModBlocks.RAINBOW_BLOCK.get())).displayItems((parameters, tabData) -> {
				tabData.accept(LinusMcModderGamersModBlocks.RAINBOW_BLOCK.get().asItem());
				tabData.accept(LinusMcModderGamersModBlocks.SLIME_TNT.get().asItem());
				tabData.accept(LinusMcModderGamersModItems.BULLET.get());
			}).build());

	@SubscribeEvent
	public static void buildTabContentsVanilla(BuildCreativeModeTabContentsEvent tabData) {
		if (tabData.getTabKey() == CreativeModeTabs.COMBAT) {
			tabData.accept(LinusMcModderGamersModItems.AMETHESTSWORD.get());
			tabData.accept(LinusMcModderGamersModItems.AMETHEST_ARMOR_HELMET.get());
			tabData.accept(LinusMcModderGamersModItems.AMETHEST_ARMOR_CHESTPLATE.get());
			tabData.accept(LinusMcModderGamersModItems.AMETHEST_ARMOR_LEGGINGS.get());
			tabData.accept(LinusMcModderGamersModItems.AMETHEST_ARMOR_BOOTS.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) {
			tabData.accept(LinusMcModderGamersModItems.AMETHESTPICKAXE.get());
			tabData.accept(LinusMcModderGamersModItems.RAINBOWDIMENSION.get());
			tabData.accept(LinusMcModderGamersModItems.PISTOL.get());
			tabData.accept(LinusMcModderGamersModItems.BULLET.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.NATURAL_BLOCKS) {
			tabData.accept(LinusMcModderGamersModBlocks.AMETHESTORE.get().asItem());
		} else if (tabData.getTabKey() == CreativeModeTabs.SPAWN_EGGS) {
			tabData.accept(LinusMcModderGamersModItems.COLORFULALLAY_SPAWN_EGG.get());
		}
	}
}