package net.mcreator.linusmcmoddergamers.item;

import net.minecraft.world.item.Item;

public class AmethestIngotItem extends Item {
	public AmethestIngotItem(Item.Properties properties) {
		super(properties);
	}
}