package net.mcreator.linusmcmoddergamers.item;

import net.minecraft.world.item.Item;

public class BulletItem extends Item {
	public BulletItem(Item.Properties properties) {
		super(properties);
	}
}