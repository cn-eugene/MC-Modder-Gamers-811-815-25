package net.mcreator.linusmcmoddergamers.item;

import net.minecraft.world.item.Item;

public class NerfdartItem extends Item {
	public NerfdartItem(Item.Properties properties) {
		super(properties);
	}
}