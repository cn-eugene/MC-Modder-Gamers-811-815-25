package net.mcreator.linusmcmoddergamers.mixin;

import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.Mixin;

import net.minecraft.world.level.levelgen.SurfaceRules;
import net.minecraft.world.level.levelgen.NoiseGeneratorSettings;
import net.minecraft.world.level.dimension.DimensionType;
import net.minecraft.core.Holder;

import net.mcreator.linusmcmoddergamers.init.LinusMcModderGamersModBiomes;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapmethod.WrapMethod;

@Mixin(NoiseGeneratorSettings.class)
public class NoiseGeneratorSettingsMixin implements LinusMcModderGamersModBiomes.LinusMcModderGamersModNoiseGeneratorSettings {
	@Unique
	private Holder<DimensionType> linus_mc_modder_gamers_dimensionTypeReference;

	@WrapMethod(method = "surfaceRule")
	public SurfaceRules.RuleSource surfaceRule(Operation<SurfaceRules.RuleSource> original) {
		SurfaceRules.RuleSource retval = original.call();
		if (this.linus_mc_modder_gamers_dimensionTypeReference != null) {
			retval = LinusMcModderGamersModBiomes.adaptSurfaceRule(retval, this.linus_mc_modder_gamers_dimensionTypeReference);
		}
		return retval;
	}

	@Override
	public void setlinus_mc_modder_gamersDimensionTypeReference(Holder<DimensionType> dimensionType) {
		this.linus_mc_modder_gamers_dimensionTypeReference = dimensionType;
	}
}