/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.fitzwilliammcmoddergamers.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.item.alchemy.Potion;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.core.registries.Registries;

import net.mcreator.fitzwilliammcmoddergamers.FitzwilliamMcModderGamersMod;

public class FitzwilliamMcModderGamersModPotions {
	public static final DeferredRegister<Potion> REGISTRY = DeferredRegister.create(Registries.POTION, FitzwilliamMcModderGamersMod.MODID);
	public static final DeferredHolder<Potion, Potion> LUCK = REGISTRY.register("luck", () -> new Potion("luck", new MobEffectInstance(MobEffects.LUCK, -1, 0, false, true)));
	public static final DeferredHolder<Potion, Potion> ST = REGISTRY.register("st",
			() -> new Potion("st", new MobEffectInstance(MobEffects.DAMAGE_BOOST, -1, 0, false, true), new MobEffectInstance(MobEffects.MOVEMENT_SPEED, -1, 0, false, true), new MobEffectInstance(MobEffects.WATER_BREATHING, -1, 0, false, true),
					new MobEffectInstance(MobEffects.DIG_SPEED, -1, 0, false, true), new MobEffectInstance(MobEffects.HEALTH_BOOST, -1, 0, false, true), new MobEffectInstance(MobEffects.REGENERATION, -1, 0, false, true)));
	public static final DeferredHolder<Potion, Potion> B = REGISTRY.register("b", () -> new Potion("b", new MobEffectInstance(MobEffects.FIRE_RESISTANCE, -1, 0, false, true), new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, -1, 0, false, true),
			new MobEffectInstance(MobEffects.NIGHT_VISION, -1, 0, false, true), new MobEffectInstance(MobEffects.JUMP, -1, 0, false, true), new MobEffectInstance(MobEffects.HERO_OF_THE_VILLAGE, -1, 0, false, true)));
}