/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.fitzwilliammcmoddergamers.init;

import org.checkerframework.checker.units.qual.A;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredBlock;

import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.Block;

import net.mcreator.fitzwilliammcmoddergamers.block.JHPortalBlock;
import net.mcreator.fitzwilliammcmoddergamers.block.FvBlock;
import net.mcreator.fitzwilliammcmoddergamers.block.DeathBlock;
import net.mcreator.fitzwilliammcmoddergamers.block.DBlock;
import net.mcreator.fitzwilliammcmoddergamers.block.ABlock;
import net.mcreator.fitzwilliammcmoddergamers.FitzwilliamMcModderGamersMod;

import java.util.function.Function;

public class FitzwilliamMcModderGamersModBlocks {
	public static final DeferredRegister.Blocks REGISTRY = DeferredRegister.createBlocks(FitzwilliamMcModderGamersMod.MODID);
	public static final DeferredBlock<Block> DEATH = register("death", DeathBlock::new);
	public static final DeferredBlock<Block> A = register("a", ABlock::new);
	public static final DeferredBlock<Block> D = register("d", DBlock::new);
	public static final DeferredBlock<Block> FV = register("fv", FvBlock::new);
	public static final DeferredBlock<Block> JH_PORTAL = register("jh_portal", JHPortalBlock::new);

	// Start of user code block custom blocks
	// End of user code block custom blocks
	private static <B extends Block> DeferredBlock<B> register(String name, Function<BlockBehaviour.Properties, ? extends B> supplier) {
		return REGISTRY.registerBlock(name, supplier, BlockBehaviour.Properties.of());
	}
}