package net.mcreator.fitzwilliammcmoddergamers.item;

import net.minecraft.world.item.Item;

public class RubyItem extends Item {
	public RubyItem(Item.Properties properties) {
		super(properties);
	}
}