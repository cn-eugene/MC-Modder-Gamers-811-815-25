package net.mcreator.fitzwilliammcmoddergamers.item;

import net.minecraft.world.item.Item;

public class TItem extends Item {
	public TItem(Item.Properties properties) {
		super(properties);
	}
}