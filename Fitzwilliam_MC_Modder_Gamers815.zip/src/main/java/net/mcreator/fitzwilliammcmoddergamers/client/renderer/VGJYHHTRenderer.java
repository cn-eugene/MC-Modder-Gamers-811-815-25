package net.mcreator.fitzwilliammcmoddergamers.client.renderer;

import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.state.VillagerRenderState;
import net.minecraft.client.renderer.entity.state.HoldingEntityRenderState;
import net.minecraft.client.renderer.entity.layers.CrossedArmsItemLayer;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.model.VillagerModel;
import net.minecraft.client.animation.definitions.BreezeAnimation;
import net.minecraft.client.animation.definitions.ArmadilloAnimation;

import net.mcreator.fitzwilliammcmoddergamers.entity.VGJYHHTEntity;

import com.mojang.blaze3d.vertex.PoseStack;

public class VGJYHHTRenderer extends MobRenderer<VGJYHHTEntity, VillagerRenderState, VillagerModel> {
	private VGJYHHTEntity entity = null;

	public VGJYHHTRenderer(EntityRendererProvider.Context context) {
		super(context, new AnimatedModel(context.bakeLayer(ModelLayers.VILLAGER)), 0.5f);
		this.addLayer(new CrossedArmsItemLayer<>(this));
	}

	@Override
	public VillagerRenderState createRenderState() {
		return new VillagerRenderState();
	}

	@Override
	public void extractRenderState(VGJYHHTEntity entity, VillagerRenderState state, float partialTicks) {
		super.extractRenderState(entity, state, partialTicks);
		this.entity = entity;
		if (this.model instanceof AnimatedModel) {
			((AnimatedModel) this.model).setEntity(entity);
		}
		if (state instanceof HoldingEntityRenderState holdingState) {
			this.itemModelResolver.updateForLiving(holdingState.heldItem, entity.getMainHandItem(), ItemDisplayContext.GROUND, false, entity);
		}
	}

	@Override
	public ResourceLocation getTextureLocation(VillagerRenderState state) {
		return ResourceLocation.parse("fitzwilliam_mc_modder_gamers:textures/entities/villager_v2.png");
	}

	@Override
	protected void scale(VillagerRenderState state, PoseStack poseStack) {
		poseStack.scale(0.9375f, 0.9375f, 0.9375f);
	}

	private static final class AnimatedModel extends VillagerModel {
		private VGJYHHTEntity entity = null;

		public AnimatedModel(ModelPart root) {
			super(root);
		}

		public void setEntity(VGJYHHTEntity entity) {
			this.entity = entity;
		}

		@Override
		public void setupAnim(VillagerRenderState state) {
			this.root().getAllParts().forEach(ModelPart::resetPose);
			this.animate(entity.animationState0, ArmadilloAnimation.ARMADILLO_PEEK, state.ageInTicks, 1f);
			this.animateWalk(BreezeAnimation.IDLE, state.walkAnimationPos, state.walkAnimationSpeed, 1f, 1f);
			this.animate(entity.animationState2, BreezeAnimation.SLIDE, state.ageInTicks, 1f);
			this.animate(entity.animationState3, BreezeAnimation.JUMP, state.ageInTicks, 1f);
			this.animate(entity.animationState4, ArmadilloAnimation.ARMADILLO_PEEK, state.ageInTicks, 1f);
			this.animate(entity.animationState5, ArmadilloAnimation.ARMADILLO_PEEK, state.ageInTicks, 1f);
			this.animate(entity.animationState6, ArmadilloAnimation.ARMADILLO_PEEK, state.ageInTicks, 1f);
			this.animate(entity.animationState7, ArmadilloAnimation.ARMADILLO_PEEK, state.ageInTicks, 1f);
			this.animate(entity.animationState8, ArmadilloAnimation.ARMADILLO_PEEK, state.ageInTicks, 1f);
			this.animate(entity.animationState9, ArmadilloAnimation.ARMADILLO_PEEK, state.ageInTicks, 1f);
			this.animate(entity.animationState10, ArmadilloAnimation.ARMADILLO_PEEK, state.ageInTicks, 1f);
			this.animate(entity.animationState11, ArmadilloAnimation.ARMADILLO_PEEK, state.ageInTicks, 1f);
			this.animate(entity.animationState12, ArmadilloAnimation.ARMADILLO_PEEK, state.ageInTicks, 1f);
			this.animate(entity.animationState13, ArmadilloAnimation.ARMADILLO_PEEK, state.ageInTicks, 1f);
			this.animate(entity.animationState14, ArmadilloAnimation.ARMADILLO_PEEK, state.ageInTicks, 1f);
			this.animate(entity.animationState15, ArmadilloAnimation.ARMADILLO_PEEK, state.ageInTicks, 1f);
			this.animate(entity.animationState16, ArmadilloAnimation.ARMADILLO_PEEK, state.ageInTicks, 1f);
			this.animate(entity.animationState17, ArmadilloAnimation.ARMADILLO_PEEK, state.ageInTicks, 1f);
			this.animate(entity.animationState18, ArmadilloAnimation.ARMADILLO_PEEK, state.ageInTicks, 1f);
			this.animate(entity.animationState19, ArmadilloAnimation.ARMADILLO_PEEK, state.ageInTicks, 1f);
			this.animate(entity.animationState20, ArmadilloAnimation.ARMADILLO_PEEK, state.ageInTicks, 1f);
			this.animate(entity.animationState21, ArmadilloAnimation.ARMADILLO_PEEK, state.ageInTicks, 1f);
			this.animate(entity.animationState22, ArmadilloAnimation.ARMADILLO_PEEK, state.ageInTicks, 1f);
			this.animate(entity.animationState23, ArmadilloAnimation.ARMADILLO_PEEK, state.ageInTicks, 1f);
			this.animate(entity.animationState24, ArmadilloAnimation.ARMADILLO_PEEK, state.ageInTicks, 1f);
			this.animate(entity.animationState25, ArmadilloAnimation.ARMADILLO_PEEK, state.ageInTicks, 1f);
			this.animate(entity.animationState26, ArmadilloAnimation.ARMADILLO_PEEK, state.ageInTicks, 1f);
			this.animate(entity.animationState27, ArmadilloAnimation.ARMADILLO_PEEK, state.ageInTicks, 1f);
			this.animate(entity.animationState28, ArmadilloAnimation.ARMADILLO_PEEK, state.ageInTicks, 1f);
			this.animate(entity.animationState29, ArmadilloAnimation.ARMADILLO_PEEK, state.ageInTicks, 1f);
			this.animate(entity.animationState30, ArmadilloAnimation.ARMADILLO_PEEK, state.ageInTicks, 1f);
			this.animate(entity.animationState31, ArmadilloAnimation.ARMADILLO_PEEK, state.ageInTicks, 1f);
			this.animate(entity.animationState32, ArmadilloAnimation.ARMADILLO_PEEK, state.ageInTicks, 1f);
			this.animate(entity.animationState33, ArmadilloAnimation.ARMADILLO_PEEK, state.ageInTicks, 1f);
			this.animate(entity.animationState34, ArmadilloAnimation.ARMADILLO_PEEK, state.ageInTicks, 1f);
			this.animate(entity.animationState35, ArmadilloAnimation.ARMADILLO_PEEK, state.ageInTicks, 1f);
			this.animate(entity.animationState36, ArmadilloAnimation.ARMADILLO_PEEK, state.ageInTicks, 1f);
			this.animate(entity.animationState37, ArmadilloAnimation.ARMADILLO_PEEK, state.ageInTicks, 1f);
			this.animate(entity.animationState38, ArmadilloAnimation.ARMADILLO_PEEK, state.ageInTicks, 1f);
			this.animate(entity.animationState39, ArmadilloAnimation.ARMADILLO_PEEK, state.ageInTicks, 1f);
			this.animate(entity.animationState40, ArmadilloAnimation.ARMADILLO_PEEK, state.ageInTicks, 1f);
			super.setupAnim(state);
		}
	}
}