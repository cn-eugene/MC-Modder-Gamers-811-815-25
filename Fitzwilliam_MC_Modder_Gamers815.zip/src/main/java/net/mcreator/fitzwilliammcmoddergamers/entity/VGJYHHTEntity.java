package net.mcreator.fitzwilliammcmoddergamers.entity;

import net.neoforged.neoforge.event.entity.RegisterSpawnPlacementsEvent;
import net.neoforged.neoforge.common.NeoForgeMod;

import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.Explosion;
import net.minecraft.world.entity.projectile.ThrownPotion;
import net.minecraft.world.entity.projectile.AbstractArrow;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.RandomStrollGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.SpawnPlacementTypes;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.AreaEffectCloud;
import net.minecraft.world.entity.AnimationState;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.Difficulty;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerBossEvent;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.BlockPos;

import net.mcreator.fitzwilliammcmoddergamers.init.FitzwilliamMcModderGamersModEntities;

public class VGJYHHTEntity extends Monster {
	public final AnimationState animationState0 = new AnimationState();
	public final AnimationState animationState2 = new AnimationState();
	public final AnimationState animationState3 = new AnimationState();
	public final AnimationState animationState4 = new AnimationState();
	public final AnimationState animationState5 = new AnimationState();
	public final AnimationState animationState6 = new AnimationState();
	public final AnimationState animationState7 = new AnimationState();
	public final AnimationState animationState8 = new AnimationState();
	public final AnimationState animationState9 = new AnimationState();
	public final AnimationState animationState10 = new AnimationState();
	public final AnimationState animationState11 = new AnimationState();
	public final AnimationState animationState12 = new AnimationState();
	public final AnimationState animationState13 = new AnimationState();
	public final AnimationState animationState14 = new AnimationState();
	public final AnimationState animationState15 = new AnimationState();
	public final AnimationState animationState16 = new AnimationState();
	public final AnimationState animationState17 = new AnimationState();
	public final AnimationState animationState18 = new AnimationState();
	public final AnimationState animationState19 = new AnimationState();
	public final AnimationState animationState20 = new AnimationState();
	public final AnimationState animationState21 = new AnimationState();
	public final AnimationState animationState22 = new AnimationState();
	public final AnimationState animationState23 = new AnimationState();
	public final AnimationState animationState24 = new AnimationState();
	public final AnimationState animationState25 = new AnimationState();
	public final AnimationState animationState26 = new AnimationState();
	public final AnimationState animationState27 = new AnimationState();
	public final AnimationState animationState28 = new AnimationState();
	public final AnimationState animationState29 = new AnimationState();
	public final AnimationState animationState30 = new AnimationState();
	public final AnimationState animationState31 = new AnimationState();
	public final AnimationState animationState32 = new AnimationState();
	public final AnimationState animationState33 = new AnimationState();
	public final AnimationState animationState34 = new AnimationState();
	public final AnimationState animationState35 = new AnimationState();
	public final AnimationState animationState36 = new AnimationState();
	public final AnimationState animationState37 = new AnimationState();
	public final AnimationState animationState38 = new AnimationState();
	public final AnimationState animationState39 = new AnimationState();
	public final AnimationState animationState40 = new AnimationState();
	private final ServerBossEvent bossInfo = new ServerBossEvent(this.getDisplayName(), ServerBossEvent.BossBarColor.PINK, ServerBossEvent.BossBarOverlay.PROGRESS);

	public VGJYHHTEntity(EntityType<VGJYHHTEntity> type, Level world) {
		super(type, world);
		xpReward = 0;
		setNoAi(false);
	}

	@Override
	protected void registerGoals() {
		super.registerGoals();
		this.goalSelector.addGoal(1, new MeleeAttackGoal(this, 1.2, false) {
			@Override
			protected boolean canPerformAttack(LivingEntity entity) {
				return this.isTimeToAttack() && this.mob.distanceToSqr(entity) < (this.mob.getBbWidth() * this.mob.getBbWidth() + entity.getBbWidth()) && this.mob.getSensing().hasLineOfSight(entity);
			}
		});
		this.goalSelector.addGoal(2, new RandomStrollGoal(this, 1));
		this.targetSelector.addGoal(3, new HurtByTargetGoal(this));
		this.goalSelector.addGoal(4, new RandomLookAroundGoal(this));
		this.goalSelector.addGoal(5, new FloatGoal(this));
	}

	@Override
	public SoundEvent getAmbientSound() {
		return BuiltInRegistries.SOUND_EVENT.getValue(ResourceLocation.parse("ambient.basalt_deltas.additions"));
	}

	@Override
	public void playStepSound(BlockPos pos, BlockState blockIn) {
		this.playSound(BuiltInRegistries.SOUND_EVENT.getValue(ResourceLocation.parse("ambient.cave")), 0.15f, 1);
	}

	@Override
	public SoundEvent getHurtSound(DamageSource ds) {
		return BuiltInRegistries.SOUND_EVENT.getValue(ResourceLocation.parse("ambient.crimson_forest.additions"));
	}

	@Override
	public SoundEvent getDeathSound() {
		return BuiltInRegistries.SOUND_EVENT.getValue(ResourceLocation.parse("ambient.soul_sand_valley.additions"));
	}

	@Override
	public boolean hurtServer(ServerLevel level, DamageSource damagesource, float amount) {
		if (damagesource.is(DamageTypes.IN_FIRE))
			return false;
		if (damagesource.getDirectEntity() instanceof AbstractArrow)
			return false;
		if (damagesource.getDirectEntity() instanceof Player)
			return false;
		if (damagesource.getDirectEntity() instanceof ThrownPotion || damagesource.getDirectEntity() instanceof AreaEffectCloud || damagesource.typeHolder().is(NeoForgeMod.POISON_DAMAGE))
			return false;
		if (damagesource.is(DamageTypes.CACTUS))
			return false;
		if (damagesource.is(DamageTypes.DROWN))
			return false;
		if (damagesource.is(DamageTypes.LIGHTNING_BOLT))
			return false;
		if (damagesource.is(DamageTypes.EXPLOSION) || damagesource.is(DamageTypes.PLAYER_EXPLOSION))
			return false;
		if (damagesource.is(DamageTypes.TRIDENT))
			return false;
		if (damagesource.is(DamageTypes.FALLING_ANVIL))
			return false;
		if (damagesource.is(DamageTypes.DRAGON_BREATH))
			return false;
		if (damagesource.is(DamageTypes.WITHER) || damagesource.is(DamageTypes.WITHER_SKULL))
			return false;
		return super.hurtServer(level, damagesource, amount);
	}

	@Override
	public boolean ignoreExplosion(Explosion explosion) {
		return true;
	}

	@Override
	public boolean fireImmune() {
		return true;
	}

	@Override
	public void tick() {
		super.tick();
		if (this.level().isClientSide()) {
			this.animationState0.animateWhen(true, this.tickCount);
			this.animationState2.animateWhen(true, this.tickCount);
			this.animationState3.animateWhen(true, this.tickCount);
			this.animationState4.animateWhen(true, this.tickCount);
			this.animationState5.animateWhen(true, this.tickCount);
			this.animationState6.animateWhen(true, this.tickCount);
			this.animationState7.animateWhen(true, this.tickCount);
			this.animationState8.animateWhen(true, this.tickCount);
			this.animationState9.animateWhen(true, this.tickCount);
			this.animationState10.animateWhen(true, this.tickCount);
			this.animationState11.animateWhen(true, this.tickCount);
			this.animationState12.animateWhen(true, this.tickCount);
			this.animationState13.animateWhen(true, this.tickCount);
			this.animationState14.animateWhen(true, this.tickCount);
			this.animationState15.animateWhen(true, this.tickCount);
			this.animationState16.animateWhen(true, this.tickCount);
			this.animationState17.animateWhen(true, this.tickCount);
			this.animationState18.animateWhen(true, this.tickCount);
			this.animationState19.animateWhen(true, this.tickCount);
			this.animationState20.animateWhen(true, this.tickCount);
			this.animationState21.animateWhen(true, this.tickCount);
			this.animationState22.animateWhen(true, this.tickCount);
			this.animationState23.animateWhen(true, this.tickCount);
			this.animationState24.animateWhen(true, this.tickCount);
			this.animationState25.animateWhen(true, this.tickCount);
			this.animationState26.animateWhen(true, this.tickCount);
			this.animationState27.animateWhen(true, this.tickCount);
			this.animationState28.animateWhen(true, this.tickCount);
			this.animationState29.animateWhen(true, this.tickCount);
			this.animationState30.animateWhen(true, this.tickCount);
			this.animationState31.animateWhen(true, this.tickCount);
			this.animationState32.animateWhen(true, this.tickCount);
			this.animationState33.animateWhen(true, this.tickCount);
			this.animationState34.animateWhen(true, this.tickCount);
			this.animationState35.animateWhen(true, this.tickCount);
			this.animationState36.animateWhen(true, this.tickCount);
			this.animationState37.animateWhen(true, this.tickCount);
			this.animationState38.animateWhen(true, this.tickCount);
			this.animationState39.animateWhen(true, this.tickCount);
			this.animationState40.animateWhen(true, this.tickCount);
		}
	}

	@Override
	public void startSeenByPlayer(ServerPlayer player) {
		super.startSeenByPlayer(player);
		this.bossInfo.addPlayer(player);
	}

	@Override
	public void stopSeenByPlayer(ServerPlayer player) {
		super.stopSeenByPlayer(player);
		this.bossInfo.removePlayer(player);
	}

	@Override
	public void customServerAiStep(ServerLevel serverLevel) {
		super.customServerAiStep(serverLevel);
		this.bossInfo.setProgress(this.getHealth() / this.getMaxHealth());
	}

	public static void init(RegisterSpawnPlacementsEvent event) {
		event.register(FitzwilliamMcModderGamersModEntities.VGJYHHT.get(), SpawnPlacementTypes.ON_GROUND, Heightmap.Types.MOTION_BLOCKING_NO_LEAVES,
				(entityType, world, reason, pos, random) -> (world.getDifficulty() != Difficulty.PEACEFUL && Monster.isDarkEnoughToSpawn(world, pos, random) && Mob.checkMobSpawnRules(entityType, world, reason, pos, random)),
				RegisterSpawnPlacementsEvent.Operation.REPLACE);
	}

	public static AttributeSupplier.Builder createAttributes() {
		AttributeSupplier.Builder builder = Mob.createMobAttributes();
		builder = builder.add(Attributes.MOVEMENT_SPEED, 1);
		builder = builder.add(Attributes.MAX_HEALTH, 1024);
		builder = builder.add(Attributes.ARMOR, 20.6);
		builder = builder.add(Attributes.ATTACK_DAMAGE, 1);
		builder = builder.add(Attributes.FOLLOW_RANGE, 1019);
		builder = builder.add(Attributes.STEP_HEIGHT, 0.6);
		builder = builder.add(Attributes.ATTACK_KNOCKBACK, 64);
		return builder;
	}
}