/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.avorivmodergamer.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.core.registries.Registries;

import net.mcreator.avorivmodergamer.AvorivModerGamerMod;

@EventBusSubscriber(bus = EventBusSubscriber.Bus.MOD)
public class AvorivModerGamerModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, AvorivModerGamerMod.MODID);

	@SubscribeEvent
	public static void buildTabContentsVanilla(BuildCreativeModeTabContentsEvent tabData) {
		if (tabData.getTabKey() == CreativeModeTabs.BUILDING_BLOCKS) {
			tabData.accept(AvorivModerGamerModBlocks.RAINBOWROCK.get().asItem());
			tabData.accept(AvorivModerGamerModBlocks.HEHEHEH.get().asItem());
		} else if (tabData.getTabKey() == CreativeModeTabs.NATURAL_BLOCKS) {
			tabData.accept(AvorivModerGamerModBlocks.RAINBOWDROP.get().asItem());
			tabData.accept(AvorivModerGamerModItems.RAINBOWDROPORE.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.COMBAT) {
			tabData.accept(AvorivModerGamerModItems.WAVESORD.get());
			tabData.accept(AvorivModerGamerModItems.WATERSORD.get());
			tabData.accept(AvorivModerGamerModItems.WAVEPICKAXE.get());
			tabData.accept(AvorivModerGamerModItems.WAVESWORD.get());
			tabData.accept(AvorivModerGamerModItems.WAVESHOVEL.get());
			tabData.accept(AvorivModerGamerModItems.WAVEARMOR_HELMET.get());
			tabData.accept(AvorivModerGamerModItems.WAVEARMOR_CHESTPLATE.get());
			tabData.accept(AvorivModerGamerModItems.WAVEARMOR_LEGGINGS.get());
			tabData.accept(AvorivModerGamerModItems.WAVEARMOR_BOOTS.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) {
			tabData.accept(AvorivModerGamerModItems.WAVEAXE.get());
			tabData.accept(AvorivModerGamerModItems.WAVEPICKAXE.get());
			tabData.accept(AvorivModerGamerModItems.WAVEHOE.get());
			tabData.accept(AvorivModerGamerModItems.WAVEDIMENSION.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.SPAWN_EGGS) {
			tabData.accept(AvorivModerGamerModItems.PREPPYWILL_SPAWN_EGG.get());
		}
	}
}