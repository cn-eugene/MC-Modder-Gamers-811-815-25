/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.avorivmodergamer.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.SpawnEggItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.mcreator.avorivmodergamer.item.YeyeItem;
import net.mcreator.avorivmodergamer.item.WaveswordItem;
import net.mcreator.avorivmodergamer.item.WavesordItem;
import net.mcreator.avorivmodergamer.item.WaveshovelItem;
import net.mcreator.avorivmodergamer.item.WavepickaxeItem;
import net.mcreator.avorivmodergamer.item.WavehoeItem;
import net.mcreator.avorivmodergamer.item.WavedimensionItem;
import net.mcreator.avorivmodergamer.item.WavebowshooterItem;
import net.mcreator.avorivmodergamer.item.WavebowItem;
import net.mcreator.avorivmodergamer.item.WaveaxeItem;
import net.mcreator.avorivmodergamer.item.WavearmorItem;
import net.mcreator.avorivmodergamer.item.WatersordItem;
import net.mcreator.avorivmodergamer.item.WateringotItem;
import net.mcreator.avorivmodergamer.item.RainbowdroporeItem;
import net.mcreator.avorivmodergamer.AvorivModerGamerMod;

import java.util.function.Function;

public class AvorivModerGamerModItems {
	public static final DeferredRegister.Items REGISTRY = DeferredRegister.createItems(AvorivModerGamerMod.MODID);
	public static final DeferredItem<Item> RAINBOWROCK = block(AvorivModerGamerModBlocks.RAINBOWROCK, new Item.Properties().fireResistant());
	public static final DeferredItem<Item> RAINBOWDROP = block(AvorivModerGamerModBlocks.RAINBOWDROP);
	public static final DeferredItem<Item> RAINBOWDROPORE = register("rainbowdropore", RainbowdroporeItem::new);
	public static final DeferredItem<Item> WATERINGOT = register("wateringot", WateringotItem::new);
	public static final DeferredItem<Item> WAVESORD = register("wavesord", WavesordItem::new);
	public static final DeferredItem<Item> WATERSORD = register("watersord", WatersordItem::new);
	public static final DeferredItem<Item> WAVEAXE = register("waveaxe", WaveaxeItem::new);
	public static final DeferredItem<Item> WAVEPICKAXE = register("wavepickaxe", WavepickaxeItem::new);
	public static final DeferredItem<Item> WAVESWORD = register("wavesword", WaveswordItem::new);
	public static final DeferredItem<Item> WAVESHOVEL = register("waveshovel", WaveshovelItem::new);
	public static final DeferredItem<Item> WAVEHOE = register("wavehoe", WavehoeItem::new);
	public static final DeferredItem<Item> WAVEARMOR_HELMET = register("wavearmor_helmet", WavearmorItem.Helmet::new);
	public static final DeferredItem<Item> WAVEARMOR_CHESTPLATE = register("wavearmor_chestplate", WavearmorItem.Chestplate::new);
	public static final DeferredItem<Item> WAVEARMOR_LEGGINGS = register("wavearmor_leggings", WavearmorItem.Leggings::new);
	public static final DeferredItem<Item> WAVEARMOR_BOOTS = register("wavearmor_boots", WavearmorItem.Boots::new);
	public static final DeferredItem<Item> WAVEBOWSHOOTER = register("wavebowshooter", WavebowshooterItem::new);
	public static final DeferredItem<Item> WAVEBOW = register("wavebow", WavebowItem::new);
	public static final DeferredItem<Item> HEHEHEH = block(AvorivModerGamerModBlocks.HEHEHEH);
	public static final DeferredItem<Item> WAVEBLOCK = block(AvorivModerGamerModBlocks.WAVEBLOCK);
	public static final DeferredItem<Item> WAVELOG = block(AvorivModerGamerModBlocks.WAVELOG);
	public static final DeferredItem<Item> WAVELEAVES = block(AvorivModerGamerModBlocks.WAVELEAVES);
	public static final DeferredItem<Item> WAVECLAY = block(AvorivModerGamerModBlocks.WAVECLAY);
	public static final DeferredItem<Item> WAVEDIMENSION = register("wavedimension", WavedimensionItem::new);
	public static final DeferredItem<Item> YEYE = register("yeye", YeyeItem::new);
	public static final DeferredItem<Item> PREPPYWILL_SPAWN_EGG = register("preppywill_spawn_egg", properties -> new SpawnEggItem(AvorivModerGamerModEntities.PREPPYWILL.get(), properties));

	// Start of user code block custom items
	// End of user code block custom items
	private static <I extends Item> DeferredItem<I> register(String name, Function<Item.Properties, ? extends I> supplier) {
		return REGISTRY.registerItem(name, supplier, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block) {
		return block(block, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block, Item.Properties properties) {
		return REGISTRY.registerItem(block.getId().getPath(), prop -> new BlockItem(block.get(), prop), properties);
	}
}