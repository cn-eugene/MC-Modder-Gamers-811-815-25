/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.avorivmodergamer.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredBlock;

import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.Block;

import net.mcreator.avorivmodergamer.block.WavelogBlock;
import net.mcreator.avorivmodergamer.block.WavedimensionPortalBlock;
import net.mcreator.avorivmodergamer.block.WaveclayBlock;
import net.mcreator.avorivmodergamer.block.WaveblockBlock;
import net.mcreator.avorivmodergamer.block.WAVELEAVESBlock;
import net.mcreator.avorivmodergamer.block.RainbowrockBlock;
import net.mcreator.avorivmodergamer.block.RainbowdropBlock;
import net.mcreator.avorivmodergamer.block.HehehehBlock;
import net.mcreator.avorivmodergamer.AvorivModerGamerMod;

import java.util.function.Function;

public class AvorivModerGamerModBlocks {
	public static final DeferredRegister.Blocks REGISTRY = DeferredRegister.createBlocks(AvorivModerGamerMod.MODID);
	public static final DeferredBlock<Block> RAINBOWROCK = register("rainbowrock", RainbowrockBlock::new);
	public static final DeferredBlock<Block> RAINBOWDROP = register("rainbowdrop", RainbowdropBlock::new);
	public static final DeferredBlock<Block> HEHEHEH = register("heheheh", HehehehBlock::new);
	public static final DeferredBlock<Block> WAVEBLOCK = register("waveblock", WaveblockBlock::new);
	public static final DeferredBlock<Block> WAVELOG = register("wavelog", WavelogBlock::new);
	public static final DeferredBlock<Block> WAVELEAVES = register("waveleaves", WAVELEAVESBlock::new);
	public static final DeferredBlock<Block> WAVECLAY = register("waveclay", WaveclayBlock::new);
	public static final DeferredBlock<Block> WAVEDIMENSION_PORTAL = register("wavedimension_portal", WavedimensionPortalBlock::new);

	// Start of user code block custom blocks
	// End of user code block custom blocks
	private static <B extends Block> DeferredBlock<B> register(String name, Function<BlockBehaviour.Properties, ? extends B> supplier) {
		return REGISTRY.registerBlock(name, supplier, BlockBehaviour.Properties.of());
	}
}