package net.mcreator.avorivmodergamer.item;

import net.minecraft.world.item.Item;

public class WateringotItem extends Item {
	public WateringotItem(Item.Properties properties) {
		super(properties);
	}
}