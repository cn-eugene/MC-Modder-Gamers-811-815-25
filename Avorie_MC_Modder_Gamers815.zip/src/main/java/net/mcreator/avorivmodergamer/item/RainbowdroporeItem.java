package net.mcreator.avorivmodergamer.item;

import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item;

public class RainbowdroporeItem extends Item {
	public RainbowdroporeItem(Item.Properties properties) {
		super(properties.rarity(Rarity.RARE));
	}

	@Override
	public float getDestroySpeed(ItemStack itemstack, BlockState state) {
		return 3f;
	}
}