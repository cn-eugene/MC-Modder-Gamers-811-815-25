package net.mcreator.avorivmodergamer.item;

import net.minecraft.world.item.Item;

public class YeyeItem extends Item {
	public YeyeItem(Item.Properties properties) {
		super(properties);
	}
}