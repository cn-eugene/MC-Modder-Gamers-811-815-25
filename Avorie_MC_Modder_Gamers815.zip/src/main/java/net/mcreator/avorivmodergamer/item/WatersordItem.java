package net.mcreator.avorivmodergamer.item;

import net.minecraft.world.item.ToolMaterial;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.item.Item;
import net.minecraft.tags.TagKey;
import net.minecraft.tags.BlockTags;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.registries.Registries;

public class WatersordItem extends SwordItem {
	private static final ToolMaterial TOOL_MATERIAL = new ToolMaterial(BlockTags.INCORRECT_FOR_NETHERITE_TOOL, 100, 7.5f, 0, 9, TagKey.create(Registries.ITEM, ResourceLocation.parse("avoriv_moder_gamer:watersord_repair_items")));

	public WatersordItem(Item.Properties properties) {
		super(TOOL_MATERIAL, 7f, 2.8f, properties);
	}
}