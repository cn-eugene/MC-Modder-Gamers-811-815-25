package net.mcreator.avorivmodergamer.item;

import net.minecraft.world.item.Item;

public class WavebowshooterItem extends Item {
	public WavebowshooterItem(Item.Properties properties) {
		super(properties);
	}
}