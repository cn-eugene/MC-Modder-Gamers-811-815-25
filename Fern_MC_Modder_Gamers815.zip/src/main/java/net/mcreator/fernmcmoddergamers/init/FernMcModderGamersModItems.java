/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.fernmcmoddergamers.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.SpawnEggItem;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.mcreator.fernmcmoddergamers.item.VoidswordItem;
import net.mcreator.fernmcmoddergamers.item.VoidshovelItem;
import net.mcreator.fernmcmoddergamers.item.VoidpickaxeItem;
import net.mcreator.fernmcmoddergamers.item.VoidingotItem;
import net.mcreator.fernmcmoddergamers.item.VoidhoeItem;
import net.mcreator.fernmcmoddergamers.item.VoidaxeItem;
import net.mcreator.fernmcmoddergamers.item.VoidarmorItem;
import net.mcreator.fernmcmoddergamers.item.SpearItem;
import net.mcreator.fernmcmoddergamers.item.RawvoidItem;
import net.mcreator.fernmcmoddergamers.item.MoonlitrealmItem;
import net.mcreator.fernmcmoddergamers.item.AcidItem;
import net.mcreator.fernmcmoddergamers.FernMcModderGamersMod;

import java.util.function.Function;

public class FernMcModderGamersModItems {
	public static final DeferredRegister.Items REGISTRY = DeferredRegister.createItems(FernMcModderGamersMod.MODID);
	public static final DeferredItem<Item> RAWRBLOCK = block(FernMcModderGamersModBlocks.RAWRBLOCK, new Item.Properties().stacksTo(16).rarity(Rarity.EPIC).fireResistant());
	public static final DeferredItem<Item> VOIDORE = block(FernMcModderGamersModBlocks.VOIDORE, new Item.Properties().rarity(Rarity.EPIC).fireResistant());
	public static final DeferredItem<Item> VOIDINGOT = register("voidingot", VoidingotItem::new);
	public static final DeferredItem<Item> VOIDSWORD = register("voidsword", VoidswordItem::new);
	public static final DeferredItem<Item> RAWVOID = register("rawvoid", RawvoidItem::new);
	public static final DeferredItem<Item> VOIDPICKAXE = register("voidpickaxe", VoidpickaxeItem::new);
	public static final DeferredItem<Item> VOIDAXE = register("voidaxe", VoidaxeItem::new);
	public static final DeferredItem<Item> VOIDHOE = register("voidhoe", VoidhoeItem::new);
	public static final DeferredItem<Item> VOIDSHOVEL = register("voidshovel", VoidshovelItem::new);
	public static final DeferredItem<Item> VOIDARMOR_HELMET = register("voidarmor_helmet", VoidarmorItem.Helmet::new);
	public static final DeferredItem<Item> VOIDARMOR_CHESTPLATE = register("voidarmor_chestplate", VoidarmorItem.Chestplate::new);
	public static final DeferredItem<Item> VOIDARMOR_LEGGINGS = register("voidarmor_leggings", VoidarmorItem.Leggings::new);
	public static final DeferredItem<Item> VOIDARMOR_BOOTS = register("voidarmor_boots", VoidarmorItem.Boots::new);
	public static final DeferredItem<Item> SPEAR = register("spear", SpearItem::new);
	public static final DeferredItem<Item> SCRATCHGRASS = block(FernMcModderGamersModBlocks.SCRATCHGRASS);
	public static final DeferredItem<Item> SCRATCHLOG = block(FernMcModderGamersModBlocks.SCRATCHLOG);
	public static final DeferredItem<Item> SCRATCHMUD = block(FernMcModderGamersModBlocks.SCRATCHMUD);
	public static final DeferredItem<Item> SCRATCHLEAF = block(FernMcModderGamersModBlocks.SCRATCHLEAF);
	public static final DeferredItem<Item> MOONLITREALM = register("moonlitrealm", MoonlitrealmItem::new);
	public static final DeferredItem<Item> MOONLITGRASS = block(FernMcModderGamersModBlocks.MOONLITGRASS, new Item.Properties().fireResistant());
	public static final DeferredItem<Item> ACID_BUCKET = register("acid_bucket", AcidItem::new);
	public static final DeferredItem<Item> LILDRAGON_SPAWN_EGG = register("lildragon_spawn_egg", properties -> new SpawnEggItem(FernMcModderGamersModEntities.LILDRAGON.get(), properties));

	// Start of user code block custom items
	// End of user code block custom items
	private static <I extends Item> DeferredItem<I> register(String name, Function<Item.Properties, ? extends I> supplier) {
		return REGISTRY.registerItem(name, supplier, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block) {
		return block(block, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block, Item.Properties properties) {
		return REGISTRY.registerItem(block.getId().getPath(), prop -> new BlockItem(block.get(), prop), properties);
	}
}