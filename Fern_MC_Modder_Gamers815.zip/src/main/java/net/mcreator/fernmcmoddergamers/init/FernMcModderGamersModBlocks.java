/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.fernmcmoddergamers.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredBlock;

import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.Block;

import net.mcreator.fernmcmoddergamers.block.VoidoreBlock;
import net.mcreator.fernmcmoddergamers.block.ScratchmudBlock;
import net.mcreator.fernmcmoddergamers.block.ScratchlogBlock;
import net.mcreator.fernmcmoddergamers.block.ScratchleafBlock;
import net.mcreator.fernmcmoddergamers.block.ScratchgrassBlock;
import net.mcreator.fernmcmoddergamers.block.RawrblockBlock;
import net.mcreator.fernmcmoddergamers.block.MoonlitrealmPortalBlock;
import net.mcreator.fernmcmoddergamers.block.MoonlitgrassBlock;
import net.mcreator.fernmcmoddergamers.block.AcidBlock;
import net.mcreator.fernmcmoddergamers.FernMcModderGamersMod;

import java.util.function.Function;

public class FernMcModderGamersModBlocks {
	public static final DeferredRegister.Blocks REGISTRY = DeferredRegister.createBlocks(FernMcModderGamersMod.MODID);
	public static final DeferredBlock<Block> RAWRBLOCK = register("rawrblock", RawrblockBlock::new);
	public static final DeferredBlock<Block> VOIDORE = register("voidore", VoidoreBlock::new);
	public static final DeferredBlock<Block> SCRATCHGRASS = register("scratchgrass", ScratchgrassBlock::new);
	public static final DeferredBlock<Block> SCRATCHLOG = register("scratchlog", ScratchlogBlock::new);
	public static final DeferredBlock<Block> SCRATCHMUD = register("scratchmud", ScratchmudBlock::new);
	public static final DeferredBlock<Block> SCRATCHLEAF = register("scratchleaf", ScratchleafBlock::new);
	public static final DeferredBlock<Block> MOONLITREALM_PORTAL = register("moonlitrealm_portal", MoonlitrealmPortalBlock::new);
	public static final DeferredBlock<Block> MOONLITGRASS = register("moonlitgrass", MoonlitgrassBlock::new);
	public static final DeferredBlock<Block> ACID = register("acid", AcidBlock::new);

	// Start of user code block custom blocks
	// End of user code block custom blocks
	private static <B extends Block> DeferredBlock<B> register(String name, Function<BlockBehaviour.Properties, ? extends B> supplier) {
		return REGISTRY.registerBlock(name, supplier, BlockBehaviour.Properties.of());
	}
}