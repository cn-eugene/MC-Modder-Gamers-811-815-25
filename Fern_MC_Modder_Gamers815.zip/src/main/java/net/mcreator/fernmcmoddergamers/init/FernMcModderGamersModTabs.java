/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.fernmcmoddergamers.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.network.chat.Component;
import net.minecraft.core.registries.Registries;

import net.mcreator.fernmcmoddergamers.FernMcModderGamersMod;

@EventBusSubscriber(bus = EventBusSubscriber.Bus.MOD)
public class FernMcModderGamersModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, FernMcModderGamersMod.MODID);
	public static final DeferredHolder<CreativeModeTab, CreativeModeTab> QUANTUMMODS = REGISTRY.register("quantummods",
			() -> CreativeModeTab.builder().title(Component.translatable("item_group.fern_mc_modder_gamers.quantummods")).icon(() -> new ItemStack(FernMcModderGamersModItems.MOONLITREALM.get())).displayItems((parameters, tabData) -> {
				tabData.accept(FernMcModderGamersModBlocks.RAWRBLOCK.get().asItem());
				tabData.accept(FernMcModderGamersModBlocks.VOIDORE.get().asItem());
				tabData.accept(FernMcModderGamersModItems.VOIDINGOT.get());
				tabData.accept(FernMcModderGamersModItems.VOIDSWORD.get());
				tabData.accept(FernMcModderGamersModItems.RAWVOID.get());
				tabData.accept(FernMcModderGamersModItems.VOIDPICKAXE.get());
				tabData.accept(FernMcModderGamersModItems.VOIDAXE.get());
				tabData.accept(FernMcModderGamersModItems.VOIDHOE.get());
				tabData.accept(FernMcModderGamersModItems.VOIDSHOVEL.get());
				tabData.accept(FernMcModderGamersModBlocks.SCRATCHGRASS.get().asItem());
				tabData.accept(FernMcModderGamersModBlocks.SCRATCHLOG.get().asItem());
				tabData.accept(FernMcModderGamersModBlocks.SCRATCHMUD.get().asItem());
				tabData.accept(FernMcModderGamersModBlocks.SCRATCHLEAF.get().asItem());
				tabData.accept(FernMcModderGamersModBlocks.MOONLITGRASS.get().asItem());
				tabData.accept(FernMcModderGamersModItems.LILDRAGON_SPAWN_EGG.get());
			}).build());

	@SubscribeEvent
	public static void buildTabContentsVanilla(BuildCreativeModeTabContentsEvent tabData) {
		if (tabData.getTabKey() == CreativeModeTabs.FUNCTIONAL_BLOCKS) {
			tabData.accept(FernMcModderGamersModBlocks.RAWRBLOCK.get().asItem());
		} else if (tabData.getTabKey() == CreativeModeTabs.NATURAL_BLOCKS) {
			tabData.accept(FernMcModderGamersModBlocks.VOIDORE.get().asItem());
			tabData.accept(FernMcModderGamersModBlocks.SCRATCHGRASS.get().asItem());
			tabData.accept(FernMcModderGamersModBlocks.SCRATCHLOG.get().asItem());
			tabData.accept(FernMcModderGamersModBlocks.SCRATCHMUD.get().asItem());
			tabData.accept(FernMcModderGamersModBlocks.SCRATCHLEAF.get().asItem());
			tabData.accept(FernMcModderGamersModBlocks.MOONLITGRASS.get().asItem());
		} else if (tabData.getTabKey() == CreativeModeTabs.INGREDIENTS) {
			tabData.accept(FernMcModderGamersModItems.VOIDINGOT.get());
			tabData.accept(FernMcModderGamersModItems.RAWVOID.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.COMBAT) {
			tabData.accept(FernMcModderGamersModItems.VOIDSWORD.get());
			tabData.accept(FernMcModderGamersModItems.VOIDARMOR_HELMET.get());
			tabData.accept(FernMcModderGamersModItems.VOIDARMOR_CHESTPLATE.get());
			tabData.accept(FernMcModderGamersModItems.VOIDARMOR_LEGGINGS.get());
			tabData.accept(FernMcModderGamersModItems.VOIDARMOR_BOOTS.get());
			tabData.accept(FernMcModderGamersModItems.SPEAR.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) {
			tabData.accept(FernMcModderGamersModItems.VOIDPICKAXE.get());
			tabData.accept(FernMcModderGamersModItems.VOIDAXE.get());
			tabData.accept(FernMcModderGamersModItems.VOIDHOE.get());
			tabData.accept(FernMcModderGamersModItems.VOIDSHOVEL.get());
			tabData.accept(FernMcModderGamersModItems.MOONLITREALM.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.SPAWN_EGGS) {
			tabData.accept(FernMcModderGamersModItems.LILDRAGON_SPAWN_EGG.get());
		}
	}
}