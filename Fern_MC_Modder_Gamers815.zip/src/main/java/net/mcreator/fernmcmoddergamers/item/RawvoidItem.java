package net.mcreator.fernmcmoddergamers.item;

import net.minecraft.world.item.Item;

public class RawvoidItem extends Item {
	public RawvoidItem(Item.Properties properties) {
		super(properties);
	}
}