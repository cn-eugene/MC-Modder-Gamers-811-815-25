package net.mcreator.fernmcmoddergamers.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class VoidingotItem extends Item {
	public VoidingotItem(Item.Properties properties) {
		super(properties.rarity(Rarity.EPIC).fireResistant());
	}
}