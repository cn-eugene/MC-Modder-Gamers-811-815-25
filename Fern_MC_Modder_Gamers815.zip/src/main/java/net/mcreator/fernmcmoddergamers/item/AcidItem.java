package net.mcreator.fernmcmoddergamers.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BucketItem;

import net.mcreator.fernmcmoddergamers.init.FernMcModderGamersModFluids;

public class AcidItem extends BucketItem {
	public AcidItem(Item.Properties properties) {
		super(FernMcModderGamersModFluids.ACID.get(), properties.craftRemainder(Items.BUCKET).stacksTo(1).rarity(Rarity.RARE));
	}
}