package net.mcreator.fernmcmoddergamers.procedures;

import net.minecraft.world.entity.Entity;

import net.mcreator.fernmcmoddergamers.entity.LildragonEntity;

public class LildragonOnInitialEntitySpawnProcedure {
	public static void execute(Entity entity) {
		if (entity == null)
			return;
		if (entity instanceof LildragonEntity _datEntSetI)
			_datEntSetI.getEntityData().set(LildragonEntity.DATA_AnimTimer, 0);
	}
}