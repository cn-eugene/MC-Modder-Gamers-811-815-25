package net.mcreator.fernmcmoddergamers.procedures;

import net.minecraft.world.entity.Entity;

public class LildragonEntityIsHurtProcedure {
	public static void execute(Entity entity) {
		if (entity == null)
			return;
		entity.setNoGravity(true);
	}
}