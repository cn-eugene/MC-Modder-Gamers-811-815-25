package net.mcreator.fernmcmoddergamers.procedures;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.Entity;
import net.minecraft.util.RandomSource;
import net.minecraft.util.Mth;

import net.mcreator.fernmcmoddergamers.entity.LildragonEntity;
import net.mcreator.fernmcmoddergamers.FernMcModderGamersMod;

public class LildragonOnEntityTickUpdateProcedure {
	public static void execute(LevelAccessor world, Entity entity) {
		if (entity == null)
			return;
		if (entity.isNoGravity()) {
			if (entity instanceof LildragonEntity _datEntSetL)
				_datEntSetL.getEntityData().set(LildragonEntity.DATA_AnimFlying, true);
			FernMcModderGamersMod.queueServerWork(600, () -> {
				entity.setNoGravity(false);
			});
		} else {
			if ((entity instanceof LildragonEntity _datEntI ? _datEntI.getEntityData().get(LildragonEntity.DATA_AnimTimer) : 0) <= 0) {
				if (Mth.nextInt(RandomSource.create(), 1, 10) == 1) {
					if (entity instanceof LildragonEntity _datEntSetL)
						_datEntSetL.getEntityData().set(LildragonEntity.DATA_AnimFlying, true);
				} else {
					if (entity instanceof LildragonEntity _datEntSetL)
						_datEntSetL.getEntityData().set(LildragonEntity.DATA_AnimFlying, false);
				}
				if (Mth.nextInt(RandomSource.create(), 1, 10) == 1) {
					if (entity instanceof LildragonEntity _datEntSetL)
						_datEntSetL.getEntityData().set(LildragonEntity.DATA_AnimWalking, true);
				} else {
					if (entity instanceof LildragonEntity _datEntSetL)
						_datEntSetL.getEntityData().set(LildragonEntity.DATA_AnimWalking, false);
				}
				if (entity instanceof LildragonEntity _datEntSetI)
					_datEntSetI.getEntityData().set(LildragonEntity.DATA_AnimTimer, 200);
			} else {
				if (entity instanceof LildragonEntity _datEntSetL)
					_datEntSetL.getEntityData().set(LildragonEntity.DATA_AnimIdle, true);
				if (entity instanceof LildragonEntity _datEntSetI)
					_datEntSetI.getEntityData().set(LildragonEntity.DATA_AnimTimer, (int) ((entity instanceof LildragonEntity _datEntI ? _datEntI.getEntityData().get(LildragonEntity.DATA_AnimTimer) : 0) - 1));
			}
		}
	}
}