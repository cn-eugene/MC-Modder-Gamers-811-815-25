package net.mcreator.fernmcmoddergamers.procedures;

import net.minecraft.world.entity.Entity;

import net.mcreator.fernmcmoddergamers.entity.LildragonEntity;

public class LildragonWalkPlaybackConditionProcedure {
	public static boolean execute(Entity entity) {
		if (entity == null)
			return false;
		return entity instanceof LildragonEntity _datEntL0 && _datEntL0.getEntityData().get(LildragonEntity.DATA_AnimWalking);
	}
}