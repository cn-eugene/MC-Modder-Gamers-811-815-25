package net.mcreator.fernmcmoddergamers.client.renderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.state.LivingEntityRenderState;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.model.geom.ModelPart;

import net.mcreator.fernmcmoddergamers.procedures.LildragonWalkPlaybackConditionProcedure;
import net.mcreator.fernmcmoddergamers.entity.LildragonEntity;
import net.mcreator.fernmcmoddergamers.client.model.animations.sillygooberWalkAnimation;
import net.mcreator.fernmcmoddergamers.client.model.animations.sillygooberIdleAnimation;
import net.mcreator.fernmcmoddergamers.client.model.animations.sillygooberFlysAnimation;
import net.mcreator.fernmcmoddergamers.client.model.Modelsillygoober;

public class LildragonRenderer extends MobRenderer<LildragonEntity, LivingEntityRenderState, Modelsillygoober> {
	private LildragonEntity entity = null;

	public LildragonRenderer(EntityRendererProvider.Context context) {
		super(context, new AnimatedModel(context.bakeLayer(Modelsillygoober.LAYER_LOCATION)), 0.5f);
	}

	@Override
	public LivingEntityRenderState createRenderState() {
		return new LivingEntityRenderState();
	}

	@Override
	public void extractRenderState(LildragonEntity entity, LivingEntityRenderState state, float partialTicks) {
		super.extractRenderState(entity, state, partialTicks);
		this.entity = entity;
		if (this.model instanceof AnimatedModel) {
			((AnimatedModel) this.model).setEntity(entity);
		}
	}

	@Override
	public ResourceLocation getTextureLocation(LivingEntityRenderState state) {
		return ResourceLocation.parse("fern_mc_modder_gamers:textures/entities/texture6.png");
	}

	private static final class AnimatedModel extends Modelsillygoober {
		private LildragonEntity entity = null;

		public AnimatedModel(ModelPart root) {
			super(root);
		}

		public void setEntity(LildragonEntity entity) {
			this.entity = entity;
		}

		@Override
		public void setupAnim(LivingEntityRenderState state) {
			this.root().getAllParts().forEach(ModelPart::resetPose);
			this.animate(entity.animationState0, sillygooberFlysAnimation.fly, state.ageInTicks, 1f);
			this.animate(entity.animationState1, sillygooberIdleAnimation.walk, state.ageInTicks, 1f);
			if (LildragonWalkPlaybackConditionProcedure.execute(entity))
				this.animateWalk(sillygooberWalkAnimation.idle, state.walkAnimationPos, state.walkAnimationSpeed, 1f, 1f);
			super.setupAnim(state);
		}
	}
}