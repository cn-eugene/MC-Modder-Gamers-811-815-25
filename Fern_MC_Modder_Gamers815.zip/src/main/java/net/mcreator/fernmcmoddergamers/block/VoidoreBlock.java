package net.mcreator.fernmcmoddergamers.block;

import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.Block;

public class VoidoreBlock extends Block {
	public VoidoreBlock(BlockBehaviour.Properties properties) {
		super(properties.strength(3.6f, 10f).requiresCorrectToolForDrops());
	}

	@Override
	public int getLightBlock(BlockState state) {
		return 15;
	}
}