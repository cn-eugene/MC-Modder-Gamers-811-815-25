package net.mcreator.fernmcmoddergamers.block;

import net.minecraft.world.level.material.PushReaction;
import net.minecraft.world.level.material.MapColor;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.LiquidBlock;

import net.mcreator.fernmcmoddergamers.init.FernMcModderGamersModFluids;

public class AcidBlock extends LiquidBlock {
	public AcidBlock(BlockBehaviour.Properties properties) {
		super(FernMcModderGamersModFluids.ACID.get(), properties.mapColor(MapColor.COLOR_LIGHT_GREEN).strength(100f).hasPostProcess((bs, br, bp) -> true).emissiveRendering((bs, br, bp) -> true).ignitedByLava().noCollission().noLootTable().liquid()
				.pushReaction(PushReaction.DESTROY).sound(SoundType.EMPTY).replaceable());
	}
}