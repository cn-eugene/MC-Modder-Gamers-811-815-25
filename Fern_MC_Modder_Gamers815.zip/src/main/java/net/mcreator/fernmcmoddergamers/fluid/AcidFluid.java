package net.mcreator.fernmcmoddergamers.fluid;

import net.neoforged.neoforge.fluids.BaseFlowingFluid;

import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.level.material.Fluid;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.LiquidBlock;

import net.mcreator.fernmcmoddergamers.init.FernMcModderGamersModItems;
import net.mcreator.fernmcmoddergamers.init.FernMcModderGamersModFluids;
import net.mcreator.fernmcmoddergamers.init.FernMcModderGamersModFluidTypes;
import net.mcreator.fernmcmoddergamers.init.FernMcModderGamersModBlocks;

public abstract class AcidFluid extends BaseFlowingFluid {
	public static final BaseFlowingFluid.Properties PROPERTIES = new BaseFlowingFluid.Properties(() -> FernMcModderGamersModFluidTypes.ACID_TYPE.get(), () -> FernMcModderGamersModFluids.ACID.get(),
			() -> FernMcModderGamersModFluids.FLOWING_ACID.get()).explosionResistance(100f).bucket(() -> FernMcModderGamersModItems.ACID_BUCKET.get()).block(() -> (LiquidBlock) FernMcModderGamersModBlocks.ACID.get());

	private AcidFluid() {
		super(PROPERTIES);
	}

	public static class Source extends AcidFluid {
		public int getAmount(FluidState state) {
			return 8;
		}

		public boolean isSource(FluidState state) {
			return true;
		}
	}

	public static class Flowing extends AcidFluid {
		protected void createFluidStateDefinition(StateDefinition.Builder<Fluid, FluidState> builder) {
			super.createFluidStateDefinition(builder);
			builder.add(LEVEL);
		}

		public int getAmount(FluidState state) {
			return state.getValue(LEVEL);
		}

		public boolean isSource(FluidState state) {
			return false;
		}
	}
}