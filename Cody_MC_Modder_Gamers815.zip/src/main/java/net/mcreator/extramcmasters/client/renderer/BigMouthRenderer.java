package net.mcreator.extramcmasters.client.renderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.state.LivingEntityRenderState;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.model.geom.ModelPart;

import net.mcreator.extramcmasters.entity.BigMouthEntity;
import net.mcreator.extramcmasters.client.model.animations.TestingWalkAnimation;
import net.mcreator.extramcmasters.client.model.animations.TestingIdleAnimation;
import net.mcreator.extramcmasters.client.model.ModelTesting;

public class BigMouthRenderer extends MobRenderer<BigMouthEntity, LivingEntityRenderState, ModelTesting> {
	private BigMouthEntity entity = null;

	public BigMouthRenderer(EntityRendererProvider.Context context) {
		super(context, new AnimatedModel(context.bakeLayer(ModelTesting.LAYER_LOCATION)), 0.5f);
	}

	@Override
	public LivingEntityRenderState createRenderState() {
		return new LivingEntityRenderState();
	}

	@Override
	public void extractRenderState(BigMouthEntity entity, LivingEntityRenderState state, float partialTicks) {
		super.extractRenderState(entity, state, partialTicks);
		this.entity = entity;
		if (this.model instanceof AnimatedModel) {
			((AnimatedModel) this.model).setEntity(entity);
		}
	}

	@Override
	public ResourceLocation getTextureLocation(LivingEntityRenderState state) {
		return ResourceLocation.parse("extramcmasters:textures/entities/texture.png");
	}

	private static final class AnimatedModel extends ModelTesting {
		private BigMouthEntity entity = null;

		public AnimatedModel(ModelPart root) {
			super(root);
		}

		public void setEntity(BigMouthEntity entity) {
			this.entity = entity;
		}

		@Override
		public void setupAnim(LivingEntityRenderState state) {
			this.root().getAllParts().forEach(ModelPart::resetPose);
			this.animate(entity.animationState0, TestingIdleAnimation.Standstillanimation, state.ageInTicks, 1f);
			this.animateWalk(TestingWalkAnimation.WalkingAnimation, state.walkAnimationPos, state.walkAnimationSpeed, 1f, 1f);
			super.setupAnim(state);
		}
	}
}