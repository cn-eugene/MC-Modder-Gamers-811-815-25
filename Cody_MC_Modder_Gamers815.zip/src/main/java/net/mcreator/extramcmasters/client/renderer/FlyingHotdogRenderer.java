package net.mcreator.extramcmasters.client.renderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.state.LivingEntityRenderState;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.model.geom.ModelPart;

import net.mcreator.extramcmasters.entity.FlyingHotdogEntity;
import net.mcreator.extramcmasters.client.model.animations.FlyingHotdogAnimation;
import net.mcreator.extramcmasters.client.model.ModelFlyingHotdog;

public class FlyingHotdogRenderer extends MobRenderer<FlyingHotdogEntity, LivingEntityRenderState, ModelFlyingHotdog> {
	private FlyingHotdogEntity entity = null;

	public FlyingHotdogRenderer(EntityRendererProvider.Context context) {
		super(context, new AnimatedModel(context.bakeLayer(ModelFlyingHotdog.LAYER_LOCATION)), 1f);
	}

	@Override
	public LivingEntityRenderState createRenderState() {
		return new LivingEntityRenderState();
	}

	@Override
	public void extractRenderState(FlyingHotdogEntity entity, LivingEntityRenderState state, float partialTicks) {
		super.extractRenderState(entity, state, partialTicks);
		this.entity = entity;
		if (this.model instanceof AnimatedModel) {
			((AnimatedModel) this.model).setEntity(entity);
		}
	}

	@Override
	public ResourceLocation getTextureLocation(LivingEntityRenderState state) {
		return ResourceLocation.parse("extramcmasters:textures/entities/flyinghottexture_1.png");
	}

	private static final class AnimatedModel extends ModelFlyingHotdog {
		private FlyingHotdogEntity entity = null;

		public AnimatedModel(ModelPart root) {
			super(root);
		}

		public void setEntity(FlyingHotdogEntity entity) {
			this.entity = entity;
		}

		@Override
		public void setupAnim(LivingEntityRenderState state) {
			this.root().getAllParts().forEach(ModelPart::resetPose);
			this.animate(entity.animationState0, FlyingHotdogAnimation.animation, state.ageInTicks, 1f);
			super.setupAnim(state);
		}
	}
}