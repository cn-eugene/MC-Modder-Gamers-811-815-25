package net.mcreator.extramcmasters.mixin;

import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.Mixin;

import net.minecraft.world.level.levelgen.SurfaceRules;
import net.minecraft.world.level.levelgen.NoiseGeneratorSettings;
import net.minecraft.world.level.dimension.DimensionType;
import net.minecraft.core.Holder;

import net.mcreator.extramcmasters.init.ExtramcmastersModBiomes;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapmethod.WrapMethod;

@Mixin(NoiseGeneratorSettings.class)
public class NoiseGeneratorSettingsMixin implements ExtramcmastersModBiomes.ExtramcmastersModNoiseGeneratorSettings {
	@Unique
	private Holder<DimensionType> extramcmasters_dimensionTypeReference;

	@WrapMethod(method = "surfaceRule")
	public SurfaceRules.RuleSource surfaceRule(Operation<SurfaceRules.RuleSource> original) {
		SurfaceRules.RuleSource retval = original.call();
		if (this.extramcmasters_dimensionTypeReference != null) {
			retval = ExtramcmastersModBiomes.adaptSurfaceRule(retval, this.extramcmasters_dimensionTypeReference);
		}
		return retval;
	}

	@Override
	public void setextramcmastersDimensionTypeReference(Holder<DimensionType> dimensionType) {
		this.extramcmasters_dimensionTypeReference = dimensionType;
	}
}