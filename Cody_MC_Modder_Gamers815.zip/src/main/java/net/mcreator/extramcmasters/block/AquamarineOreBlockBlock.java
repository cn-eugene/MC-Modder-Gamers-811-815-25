package net.mcreator.extramcmasters.block;

import org.checkerframework.checker.units.qual.s;

import net.neoforged.neoforge.common.util.DeferredSoundType;

import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.Block;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.registries.BuiltInRegistries;

public class AquamarineOreBlockBlock extends Block {
	public AquamarineOreBlockBlock(BlockBehaviour.Properties properties) {
		super(properties.sound(new DeferredSoundType(1.0f, 1.0f, () -> BuiltInRegistries.SOUND_EVENT.getValue(ResourceLocation.parse("item.armor.equip_diamond")),
				() -> BuiltInRegistries.SOUND_EVENT.getValue(ResourceLocation.parse("block.bone_block.hit")), () -> BuiltInRegistries.SOUND_EVENT.getValue(ResourceLocation.parse("block.stone.place")),
				() -> BuiltInRegistries.SOUND_EVENT.getValue(ResourceLocation.parse("ambient.crimson_forest.additions")), () -> BuiltInRegistries.SOUND_EVENT.getValue(ResourceLocation.parse("ambient.nether_wastes.loop")))).strength(2f, 10f)
				.lightLevel(s -> 5));
	}

	@Override
	public int getLightBlock(BlockState state) {
		return 15;
	}
}