/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.extramcmasters.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.SpawnEggItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.mcreator.extramcmasters.item.WardenSlayerItem;
import net.mcreator.extramcmasters.item.SpearItem;
import net.mcreator.extramcmasters.item.HotDogItem;
import net.mcreator.extramcmasters.item.DarkFireBallItem;
import net.mcreator.extramcmasters.item.BigMouthEggItem;
import net.mcreator.extramcmasters.item.AquamarineSpearItem;
import net.mcreator.extramcmasters.item.AquamarineIngotItem;
import net.mcreator.extramcmasters.ExtramcmastersMod;

import java.util.function.Function;

public class ExtramcmastersModItems {
	public static final DeferredRegister.Items REGISTRY = DeferredRegister.createItems(ExtramcmastersMod.MODID);
	public static final DeferredItem<Item> AQUAMARINE_INGOT = register("aquamarine_ingot", AquamarineIngotItem::new);
	public static final DeferredItem<Item> AQUAMARINE_ORE_BLOCK = block(ExtramcmastersModBlocks.AQUAMARINE_ORE_BLOCK);
	public static final DeferredItem<Item> BLOCKOF_AQUAMARINE = block(ExtramcmastersModBlocks.BLOCKOF_AQUAMARINE);
	public static final DeferredItem<Item> BIG_MOUTH_SPAWN_EGG = register("big_mouth_spawn_egg", properties -> new SpawnEggItem(ExtramcmastersModEntities.BIG_MOUTH.get(), properties));
	public static final DeferredItem<Item> BIG_MOUTH_EGG = register("big_mouth_egg", BigMouthEggItem::new);
	public static final DeferredItem<Item> AQUAMARINE_SPEAR = register("aquamarine_spear", AquamarineSpearItem::new);
	public static final DeferredItem<Item> DARK_FIRE_BALL = register("dark_fire_ball", DarkFireBallItem::new);
	public static final DeferredItem<Item> WARDEN_SLAYER = register("warden_slayer", WardenSlayerItem::new);
	public static final DeferredItem<Item> GLITCHED_TNT = block(ExtramcmastersModBlocks.GLITCHED_TNT);
	public static final DeferredItem<Item> PALE_GRASS_BLOCK = block(ExtramcmastersModBlocks.PALE_GRASS_BLOCK);
	public static final DeferredItem<Item> SPEAR = register("spear", SpearItem::new);
	public static final DeferredItem<Item> MUTED_LOG = block(ExtramcmastersModBlocks.MUTED_LOG);
	public static final DeferredItem<Item> MUTED_CLAY = block(ExtramcmastersModBlocks.MUTED_CLAY);
	public static final DeferredItem<Item> MUTED_LEAVES = block(ExtramcmastersModBlocks.MUTED_LEAVES);
	public static final DeferredItem<Item> FLYING_HOTDOG_SPAWN_EGG = register("flying_hotdog_spawn_egg", properties -> new SpawnEggItem(ExtramcmastersModEntities.FLYING_HOTDOG.get(), properties));
	public static final DeferredItem<Item> HOT_DOG = register("hot_dog", HotDogItem::new);
	public static final DeferredItem<Item> MUTED_PLANKS = block(ExtramcmastersModBlocks.MUTED_PLANKS);

	// Start of user code block custom items
	// End of user code block custom items
	private static <I extends Item> DeferredItem<I> register(String name, Function<Item.Properties, ? extends I> supplier) {
		return REGISTRY.registerItem(name, supplier, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block) {
		return block(block, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block, Item.Properties properties) {
		return REGISTRY.registerItem(block.getId().getPath(), prop -> new BlockItem(block.get(), prop), properties);
	}
}