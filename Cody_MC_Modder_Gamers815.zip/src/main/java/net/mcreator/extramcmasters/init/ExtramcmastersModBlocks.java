/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.extramcmasters.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredBlock;

import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.Block;

import net.mcreator.extramcmasters.block.PaleGrassBlockBlock;
import net.mcreator.extramcmasters.block.MutedPlanksBlock;
import net.mcreator.extramcmasters.block.MutedLogBlock;
import net.mcreator.extramcmasters.block.MutedLeavesBlock;
import net.mcreator.extramcmasters.block.MutedClayBlock;
import net.mcreator.extramcmasters.block.GlitchedTNTBlock;
import net.mcreator.extramcmasters.block.BlockofAquamarineBlock;
import net.mcreator.extramcmasters.block.AquamarineOreBlockBlock;
import net.mcreator.extramcmasters.ExtramcmastersMod;

import java.util.function.Function;

public class ExtramcmastersModBlocks {
	public static final DeferredRegister.Blocks REGISTRY = DeferredRegister.createBlocks(ExtramcmastersMod.MODID);
	public static final DeferredBlock<Block> AQUAMARINE_ORE_BLOCK = register("aquamarine_ore_block", AquamarineOreBlockBlock::new);
	public static final DeferredBlock<Block> BLOCKOF_AQUAMARINE = register("blockof_aquamarine", BlockofAquamarineBlock::new);
	public static final DeferredBlock<Block> GLITCHED_TNT = register("glitched_tnt", GlitchedTNTBlock::new);
	public static final DeferredBlock<Block> PALE_GRASS_BLOCK = register("pale_grass_block", PaleGrassBlockBlock::new);
	public static final DeferredBlock<Block> MUTED_LOG = register("muted_log", MutedLogBlock::new);
	public static final DeferredBlock<Block> MUTED_CLAY = register("muted_clay", MutedClayBlock::new);
	public static final DeferredBlock<Block> MUTED_LEAVES = register("muted_leaves", MutedLeavesBlock::new);
	public static final DeferredBlock<Block> MUTED_PLANKS = register("muted_planks", MutedPlanksBlock::new);

	// Start of user code block custom blocks
	// End of user code block custom blocks
	private static <B extends Block> DeferredBlock<B> register(String name, Function<BlockBehaviour.Properties, ? extends B> supplier) {
		return REGISTRY.registerBlock(name, supplier, BlockBehaviour.Properties.of());
	}
}