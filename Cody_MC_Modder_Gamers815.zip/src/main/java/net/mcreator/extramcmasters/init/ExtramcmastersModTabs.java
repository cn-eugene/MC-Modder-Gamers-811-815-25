/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.extramcmasters.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.network.chat.Component;
import net.minecraft.core.registries.Registries;

import net.mcreator.extramcmasters.ExtramcmastersMod;

@EventBusSubscriber(bus = EventBusSubscriber.Bus.MOD)
public class ExtramcmastersModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, ExtramcmastersMod.MODID);
	public static final DeferredHolder<CreativeModeTab, CreativeModeTab> MOD_TAB = REGISTRY.register("mod_tab",
			() -> CreativeModeTab.builder().title(Component.translatable("item_group.extramcmasters.mod_tab")).icon(() -> new ItemStack(ExtramcmastersModBlocks.PALE_GRASS_BLOCK.get())).displayItems((parameters, tabData) -> {
				tabData.accept(ExtramcmastersModItems.AQUAMARINE_INGOT.get());
				tabData.accept(ExtramcmastersModBlocks.AQUAMARINE_ORE_BLOCK.get().asItem());
				tabData.accept(ExtramcmastersModBlocks.BLOCKOF_AQUAMARINE.get().asItem());
				tabData.accept(ExtramcmastersModItems.BIG_MOUTH_EGG.get());
				tabData.accept(ExtramcmastersModItems.AQUAMARINE_SPEAR.get());
				tabData.accept(ExtramcmastersModItems.DARK_FIRE_BALL.get());
				tabData.accept(ExtramcmastersModItems.WARDEN_SLAYER.get());
				tabData.accept(ExtramcmastersModBlocks.GLITCHED_TNT.get().asItem());
				tabData.accept(ExtramcmastersModBlocks.PALE_GRASS_BLOCK.get().asItem());
				tabData.accept(ExtramcmastersModItems.SPEAR.get());
				tabData.accept(ExtramcmastersModBlocks.MUTED_LOG.get().asItem());
				tabData.accept(ExtramcmastersModBlocks.MUTED_CLAY.get().asItem());
				tabData.accept(ExtramcmastersModBlocks.MUTED_LEAVES.get().asItem());
				tabData.accept(ExtramcmastersModItems.HOT_DOG.get());
				tabData.accept(ExtramcmastersModBlocks.MUTED_PLANKS.get().asItem());
			}).build());

	@SubscribeEvent
	public static void buildTabContentsVanilla(BuildCreativeModeTabContentsEvent tabData) {
		if (tabData.getTabKey() == CreativeModeTabs.INGREDIENTS) {
			tabData.accept(ExtramcmastersModItems.AQUAMARINE_INGOT.get());
			tabData.accept(ExtramcmastersModItems.BIG_MOUTH_EGG.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.FUNCTIONAL_BLOCKS) {
			tabData.accept(ExtramcmastersModBlocks.AQUAMARINE_ORE_BLOCK.get().asItem());
		} else if (tabData.getTabKey() == CreativeModeTabs.NATURAL_BLOCKS) {
			tabData.accept(ExtramcmastersModBlocks.AQUAMARINE_ORE_BLOCK.get().asItem());
			tabData.accept(ExtramcmastersModBlocks.PALE_GRASS_BLOCK.get().asItem());
			tabData.accept(ExtramcmastersModBlocks.MUTED_PLANKS.get().asItem());
		} else if (tabData.getTabKey() == CreativeModeTabs.SPAWN_EGGS) {
			tabData.accept(ExtramcmastersModItems.BIG_MOUTH_SPAWN_EGG.get());
			tabData.accept(ExtramcmastersModItems.FLYING_HOTDOG_SPAWN_EGG.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) {
			tabData.accept(ExtramcmastersModItems.AQUAMARINE_SPEAR.get());
			tabData.accept(ExtramcmastersModItems.SPEAR.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.COMBAT) {
			tabData.accept(ExtramcmastersModItems.DARK_FIRE_BALL.get());
			tabData.accept(ExtramcmastersModItems.WARDEN_SLAYER.get());
			tabData.accept(ExtramcmastersModItems.SPEAR.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.REDSTONE_BLOCKS) {
			tabData.accept(ExtramcmastersModBlocks.GLITCHED_TNT.get().asItem());
		} else if (tabData.getTabKey() == CreativeModeTabs.FOOD_AND_DRINKS) {
			tabData.accept(ExtramcmastersModItems.HOT_DOG.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.BUILDING_BLOCKS) {
			tabData.accept(ExtramcmastersModBlocks.MUTED_PLANKS.get().asItem());
		}
	}
}