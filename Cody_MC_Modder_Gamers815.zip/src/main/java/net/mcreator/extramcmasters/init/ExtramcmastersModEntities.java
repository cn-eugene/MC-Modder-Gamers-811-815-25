/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.extramcmasters.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.event.entity.RegisterSpawnPlacementsEvent;
import net.neoforged.neoforge.event.entity.EntityAttributeCreationEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Entity;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.resources.ResourceKey;
import net.minecraft.core.registries.Registries;

import net.mcreator.extramcmasters.entity.SpearProjectileEntity;
import net.mcreator.extramcmasters.entity.FlyingHotdogEntity;
import net.mcreator.extramcmasters.entity.DarkFireBallProjectileEntity;
import net.mcreator.extramcmasters.entity.BigMouthEntity;
import net.mcreator.extramcmasters.ExtramcmastersMod;

@EventBusSubscriber(bus = EventBusSubscriber.Bus.MOD)
public class ExtramcmastersModEntities {
	public static final DeferredRegister<EntityType<?>> REGISTRY = DeferredRegister.create(Registries.ENTITY_TYPE, ExtramcmastersMod.MODID);
	public static final DeferredHolder<EntityType<?>, EntityType<BigMouthEntity>> BIG_MOUTH = register("big_mouth",
			EntityType.Builder.<BigMouthEntity>of(BigMouthEntity::new, MobCategory.CREATURE).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).fireImmune()

					.sized(0.6f, 1.8f));
	public static final DeferredHolder<EntityType<?>, EntityType<DarkFireBallProjectileEntity>> DARK_FIRE_BALL_PROJECTILE = register("dark_fire_ball_projectile",
			EntityType.Builder.<DarkFireBallProjectileEntity>of(DarkFireBallProjectileEntity::new, MobCategory.MISC).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).sized(0.5f, 0.5f));
	public static final DeferredHolder<EntityType<?>, EntityType<SpearProjectileEntity>> SPEAR_PROJECTILE = register("spear_projectile",
			EntityType.Builder.<SpearProjectileEntity>of(SpearProjectileEntity::new, MobCategory.MISC).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).sized(0.5f, 0.5f));
	public static final DeferredHolder<EntityType<?>, EntityType<FlyingHotdogEntity>> FLYING_HOTDOG = register("flying_hotdog",
			EntityType.Builder.<FlyingHotdogEntity>of(FlyingHotdogEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).fireImmune()

					.sized(1f, 2f));

	// Start of user code block custom entities
	// End of user code block custom entities
	private static <T extends Entity> DeferredHolder<EntityType<?>, EntityType<T>> register(String registryname, EntityType.Builder<T> entityTypeBuilder) {
		return REGISTRY.register(registryname, () -> (EntityType<T>) entityTypeBuilder.build(ResourceKey.create(Registries.ENTITY_TYPE, ResourceLocation.fromNamespaceAndPath(ExtramcmastersMod.MODID, registryname))));
	}

	@SubscribeEvent
	public static void init(RegisterSpawnPlacementsEvent event) {
		BigMouthEntity.init(event);
		FlyingHotdogEntity.init(event);
	}

	@SubscribeEvent
	public static void registerAttributes(EntityAttributeCreationEvent event) {
		event.put(BIG_MOUTH.get(), BigMouthEntity.createAttributes().build());
		event.put(FLYING_HOTDOG.get(), FlyingHotdogEntity.createAttributes().build());
	}
}