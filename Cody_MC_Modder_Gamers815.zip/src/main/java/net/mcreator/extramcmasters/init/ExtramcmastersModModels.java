/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.extramcmasters.init;

import net.neoforged.neoforge.client.event.EntityRenderersEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.api.distmarker.Dist;

import net.mcreator.extramcmasters.client.model.ModelTesting;
import net.mcreator.extramcmasters.client.model.ModelSpear;
import net.mcreator.extramcmasters.client.model.ModelFlyingHotdog;

@EventBusSubscriber(bus = EventBusSubscriber.Bus.MOD, value = {Dist.CLIENT})
public class ExtramcmastersModModels {
	@SubscribeEvent
	public static void registerLayerDefinitions(EntityRenderersEvent.RegisterLayerDefinitions event) {
		event.registerLayerDefinition(ModelSpear.LAYER_LOCATION, ModelSpear::createBodyLayer);
		event.registerLayerDefinition(ModelFlyingHotdog.LAYER_LOCATION, ModelFlyingHotdog::createBodyLayer);
		event.registerLayerDefinition(ModelTesting.LAYER_LOCATION, ModelTesting::createBodyLayer);
	}
}