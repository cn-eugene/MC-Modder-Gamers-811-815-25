package net.mcreator.extramcmasters.item;

import net.minecraft.world.item.Item;
import net.minecraft.world.item.FishingRodItem;
import net.minecraft.tags.TagKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.registries.Registries;

public class AquamarineSpearItem extends FishingRodItem {
	public AquamarineSpearItem(Item.Properties properties) {
		super(properties.durability(1000).repairable(TagKey.create(Registries.ITEM, ResourceLocation.parse("extramcmasters:aquamarine_spear_repair_items"))).enchantable(2));
	}
}