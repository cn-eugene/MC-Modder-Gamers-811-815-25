package net.mcreator.extramcmasters.item;

import net.minecraft.world.item.Item;

public class AquamarineIngotItem extends Item {
	public AquamarineIngotItem(Item.Properties properties) {
		super(properties);
	}
}