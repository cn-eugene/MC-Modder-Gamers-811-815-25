package net.mcreator.extramcmasters.item;

import net.minecraft.world.item.Item;

public class DarkFireBallItem extends Item {
	public DarkFireBallItem(Item.Properties properties) {
		super(properties);
	}
}