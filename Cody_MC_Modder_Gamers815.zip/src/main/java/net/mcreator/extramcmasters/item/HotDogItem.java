package net.mcreator.extramcmasters.item;

import net.minecraft.world.item.component.Consumables;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.Item;
import net.minecraft.world.food.FoodProperties;

public class HotDogItem extends Item {
	public HotDogItem(Item.Properties properties) {
		super(properties.rarity(Rarity.EPIC).food((new FoodProperties.Builder()).nutrition(5).saturationModifier(0.3f).alwaysEdible().build(), Consumables.defaultFood().consumeSeconds(0F).build()).usingConvertsTo(Items.DIAMOND));
	}
}